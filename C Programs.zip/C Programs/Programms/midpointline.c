#include<stdio.h>
#include<conio.h>

double midpoint(int x1,int y1,int x2,int y2)
{
    printf("Midpoint between two points having coordinates(%d,%d)and(%d,%d)is:(%.2lf,%.2lf)",x1,y1,x2,y2,(double)((x1+x2)/2.0),(double)((y1+y2)/2.0));
}

void main()
{
    int x1,x2,y1,y2;
    
    x1=3;
    y1=7;
    x2=8;
    y2=12;

    midpoint(3,7,8,12);
    getch();

}
