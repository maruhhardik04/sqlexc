#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
    char str[20];
    char rev[20];
    int i,j=0,len=0;

    clrscr();
    printf("Enter A string:");
    gets(str);

    len=strlen(str);

    printf("%d",len);
    for(i=len;str[i]>0;i--)
    {
	printf("%s",str);
	rev[j]=str[i];
	j++;
    }

    printf("%s",str[i]);
    getch();

}