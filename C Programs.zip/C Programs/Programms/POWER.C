#include<stdio.h>
#include<conio.h>
long res=1;

long power1(int x,int n)
{

    if(n!=0)
    {
	res*=x;
	n--;
	power1(x,n);
    }
    return res;


}


long power2(int x,int n)
{
   long temp;
    if(n==0)
	return 1;

    temp=power2(x,n/2);
    if(n%2==0)
	return (long)temp*temp;
    else
	return (long)x*temp*temp;

}


int power(int x,int n)
{
    int i,res1=1;

    for(i=0;i<n;i++)
    {

	res1*=x;
    }

    return res1;

}

void main()
{
    int n,x;
    printf("Enter The Value of:");
    scanf("%d %d",&x,&n);
    printf("X^n is :%ld",power2(x,n));
    getch();
}