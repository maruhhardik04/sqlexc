#include<stdio.h>

int main()
{
    int Marks[5],total=0;
    for (int i = 0; i < 5; i++)
    {
        printf("Enter Marks of Subject%d:",i+1);
        scanf("%d",&Marks[i]);
        total += Marks[i];
    }
    printf("Sum Of Subject is:%d",total);
    return 0;

}