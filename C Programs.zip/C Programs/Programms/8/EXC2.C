#include<stdio.h>
#include<conio.h>
#include<math.h>


double height(int v,int t)
{
    return (double)(0.5*v*v*sin(t*3.14/180)*sin(t*3.14/180))/32.2;
}

int main()
{
    int v,t;
    printf("Enter Velocity:");
    scanf("%d",&v);
    printf("Enter Degree:");
    scanf("%d",&t);
    printf("Height :%lf",height((v),t));
    getch();
	return 0;
}
