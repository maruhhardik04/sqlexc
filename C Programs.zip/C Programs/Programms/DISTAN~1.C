#include<stdio.h>
#include<conio.h>
#include<math.h>

void main()
{

    int x1,x2,y1,y2;
    x1=-12;
    y1=-15;
    x2=22;
    y2=5;

    printf("Distance between two points having coordinates(%d,%d)and(%d,%d)is:%lf",x1,y1,x2,y2,(double)sqrt(pow((x1-x2),2)+pow((y1-y2),2)));

    getch();
}