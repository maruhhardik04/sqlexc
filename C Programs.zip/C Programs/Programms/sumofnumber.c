#include<stdio.h>


int main()
{
     int numberOfSubject,sum,Subject,avg=1;
     printf("Enter Number of Subjects:\n");
     scanf("%d",&numberOfSubject);
     
     for (int i = 1; i <= numberOfSubject ; i++)
     {
          printf("Enter Marks of Subject %d:\n",i);
          scanf("%d",&Subject);
          printf("Marks of Subject %d\n",Subject);

          sum += Subject;
          
     }
     printf("Sum of All Sunject:%d\n",sum);
     printf("Avg is:%d",sum/numberOfSubject);
    
    return 0;
}