#include<stdio.h>
#include<conio.h>

int slopoftheline(int x1,int y1,int x2,int y2)
{
        return (y2-y1)/(x2-x1);
}

int midpoint(int x1,int y1,int x2,int y2)
{
    return ((x1+x2)/2,(y1+y2)/2));
}

void main()
{
    int x1,x2,y1,y2,slop;
    x1=3;
    y1=7;
    x2=8;
    y2=12;

    printf("Slop of a line between two points(%d,%d)and(%d,%d)is:%d",x1,y1,x2,y2,slopoftheline(x1,y1,x2,y2));
    

    getch();
}
