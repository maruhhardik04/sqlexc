#include <stdio.h>

void main() {

    int num;
    char ch;




    do
    {
    printf("Enter any number:");
    scanf("%d",&num);
    if(num & 1){
	printf("%d is odd.",num); }
    else
    {
	printf("%d is even.",num);
     }

    printf("\nDo You Wnat More [Y/N]?");
    scanf(" %c",&ch,1);

    }while(ch=='y'|| ch=='Y');

    getch();
}