#include<stdio.h>
#include<conio.h>

void main()
{
    int x1,x2,y1,y2,slop;
    clrscr();
    x1=2;
    y1=10;
    x2=12;
    y2=6;


    printf("Midpoint between two points having coordinates(%d,%d)and(%d,%d)is:(%d,%d)",x1,y1,x2,y2,((x1+x2)/2),((y1+y2)/2));
	getch();

}
