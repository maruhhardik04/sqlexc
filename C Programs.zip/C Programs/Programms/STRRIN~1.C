#include<stdio.h>
#include<conio.h>

void main()
{

    char str[100];
    int i,len=0,spac=1;
    int cha[10];
    printf("Enter a String:");
    gets(str);
    for(i=0;str[i]!='/0';i++)
    {
	if(str[i] == ' ')
	{
	       spac++;
	}
	len++;
    }
    printf("%d %d",len,spac);

    getch();
}