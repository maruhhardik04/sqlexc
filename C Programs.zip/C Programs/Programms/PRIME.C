#include<stdio.h>
#include<conio.h>


int main()
{
   int count,n,i,j,n1=0;

    printf("Enter How Many Prime number You Want:");
    scanf("%d",&n);


    for (j=2;n1<=n;j++)
    {
        count=0;
        for (i=2;i<j;i++)
        {
            if(j%i==0)
			{ 
			count++;
            n1++;
            break;
            } 
        }
        if(count==0)
        {
	         printf("\n %d",j);
        }
    
        
    }
    return 0;
    
}
