#include<stdio.h>
#include<conio.h>
#include<math.h>
int fact[100];
int falg=0;

int CheckPrime(int i,int num)
{
        if(num==i)
            return 0;
        else
        {
            if(num%i==0)
                return 1;
            else
                return CheckPrime(i+1,num);    
        }    
}


void primeFactors(int n)
{   
	int i;
    while(n%2==0)
    {
        printf(" %d ",2);
        fact[falg]=2;
        falg++;
        n/=2;
    }
    

    for (i = 3;i <=sqrt(n);i=i+2)
    {
        while(n%i==0)
        {
            printf(" %d ",i);
            fact[falg]=i;
            falg++;
            n/=i;
        }
        
    }

     if(n>2)
         printf(" %d ",n);
         fact[falg]=n;

}


int main()
{
    int n,i;
    printf("Enter Value of N:");
    scanf("%d",&n);
    primeFactors(n);
    printf("\n");
    for (i=0; i <=falg;i++)
    {
        if(CheckPrime(2,fact[i])==0)
        {
            printf(" Yes ");
        }
        else
        {
            printf(" NO ");
        }
       
        
    }
    
    getch();
    return 0;
}
