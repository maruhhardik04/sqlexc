#include<stdio.h>

int main(int argc, char const *argv[])
{


    int Num;

    
      printf("Enter Number 1:");
      scanf("%d",&Num);
      
     if (Num == 0)
     {
        printf("You Enter Zero");
         
     }
     else if (Num < 0)
     {
        printf("Enter Number is Negative");
     }
     else
     {
       printf("Enter Number is Positive");
     }
     
     
     

    return 0;
}
