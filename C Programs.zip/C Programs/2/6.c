#include<stdio.h>

int main(int argc, char const *argv[])
{
    char a = 'E';

    if(a == 'a'|| a == 'e' || a == 'i' || a == 'o' || a == 'u' || a == 'A'|| a == 'E' || a == 'I' || a == 'O' || a == 'U')
    {
        printf("Enter Character is Vowel");
    }
    else
    {
        printf("Enter character is consonant");
    }
    

    return 0;
}
