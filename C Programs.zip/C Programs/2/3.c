#include<stdio.h>

int main(int argc, char const *argv[])
{
    
    int n1=30,n2=50,n3=20;

     int max=n1;
     (max<n2) && (max=n2);
     (max<n3) && (max=n3);

     printf("%d",max);
     

    return 0;
}
