#include<stdio.h>

int main(int argc, char const *argv[])
{
    char a='s';

    printf("%c in Upper case %c",a,a-32);

    return 0;
}
