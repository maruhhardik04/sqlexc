#include <stdio.h>

int main(int argc, char const *argv[])
{
    int n1=10;

    if(n1%2==0)
    {
        printf("Even");
    }
    else
    {
        printf("Odd");
    }
    
    return 0;
}
