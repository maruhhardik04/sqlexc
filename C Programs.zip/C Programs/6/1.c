#include<stdio.h>

int main(int argc, char const *argv[])
{
     int number[5];
      for (int i = 0; i < 5; i++)
    {
        printf("Enter Number %d:",i+1);
        scanf("%d",&number[i]);
    }
    printf("======================");
    for (int i = 0; i < 5; i++)
    {
         printf("\nNumber %d:%d",i+1,number[i]);
    }

    return 0;
}
