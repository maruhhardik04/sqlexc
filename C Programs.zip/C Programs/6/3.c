#include<stdio.h>

int main(int argc, char const *argv[])
{
    int number[10];
    int Positive=0,Negative=0,Zero=0;
    for (int i = 0; i < 10; i++)
    {
        printf("Enter Number %d:",i+1);
        scanf("%d",&number[i]);
    }

    for (int i = 0; i < 10; i++)
    {
        if (number[i] == 0)
     {
        Zero++;   
     }
     else if (number[i] < 0)
     {
        Negative++;
     }
     else
     {
       Positive++;
     }
    }
    
    printf("\nTotal Positive:%d",Positive);
     printf("\nTotal Negative:%d",Negative);
    printf("\nTotal Zero:%d",Zero);  
    
    return 0;
}
