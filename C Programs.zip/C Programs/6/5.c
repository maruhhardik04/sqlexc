#include<stdio.h>

int main(int argc, char const *argv[])
{
    int arr[10]={1,7,3,6,2,8,4,9,10,5};
    int flag1;
    
    for (int i = 0; i < 10; i++)
    {
        for (int j = i+1; j < 10;j++)
    {
        
         if(arr[i]>arr[j])
        {
             flag1 = arr[i];
             arr[i]=arr[j];  
             arr[j]=flag1;    
        }

    
    }
        for (int i = 0; i < 10; i++)
        {
         printf(" %d ",arr[i]);
        }
         printf(" \n ");
    }
          
 

    return 0;
}
