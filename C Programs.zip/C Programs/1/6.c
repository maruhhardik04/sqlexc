#include<stdio.h>

void SwapWithTemp(int a,int b)
{
    int temp=0;
   temp = a;
   a=b;
   b=temp;
    printf("After Swap With Temp \n Value of A:%d \n Value of B:%d\n",a,b);
}


void Swap(int a,int b)
{
    a = a+b;
    a = a-b;
    b = a-b;
    printf("\nAfter Swap With\n  Value of A:%d \n Value of B:%d",a,b);
     
}



int main(int argc, char const *argv[])
{
    int a,b;

    printf("Enter Number 1:");
    scanf("%d",&a);

    
    printf("Enter Number 2:");
    scanf("%d",&b);


    SwapWithTemp(a,b);
    printf("========================================================================");
    Swap(a,b);
    return 0;
}
