#include<stdio.h>

int main(int argc, char const *argv[])
{
    char Name[20];
    char Address[100];    
    printf("Enter A Name:");
    scanf("%s",&Name);
    printf("Enter Address:");
    scanf("%s",&Address);
    
    printf("Name is: %s And Your  Address is: %s",Name,Address);

    return 0;
}
