#include<stdio.h>

int main(int argc, char const *argv[])
{
    int days=0;
    printf("Enter Days:");
    scanf("%d",&days);

    int month = (days/30);
    int remaindays=days-(30*month);

    printf("%d month & %d days",month,remaindays); 
    return 0;
}
