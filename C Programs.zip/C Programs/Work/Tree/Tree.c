#include<stdio.h>
#include<stdlib.h>
struct Node 
{
    int data;
    struct Node* left;
    struct  Node* right; 
};

struct Node* CreateNode(int data)
{
  struct Node *node;
  node=(struct Node*)malloc(sizeof(struct Node));
    

    node->data=data;
    node->left=NULL;
    node->right=NULL;

    return node;

}

void Trave(struct Node *p)
{
    if(p == NULL) return;
    Trave(p->left);
    printf("\n Data:%d",p->data);
    Trave(p->right);
    
}


int main()
{

struct Node *root;
root=CreateNode(1);

root->left=CreateNode(2);
root->right=CreateNode(3);
root->left->left=CreateNode(4);
root->left->right=CreateNode(5);
root->right->left=CreateNode(6);
root->right->right=CreateNode(7);
Trave(root);

}