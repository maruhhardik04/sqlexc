#include<stdio.h>
#include<conio.h>

double compute(int x,int n)
{
   double fact=1.0,powx=1.0;
    while(n>=1)
    {  
      powx*=x;
	  fact*=n;
	  n--;
    }
    return (powx/fact);
					    
}
int main()
{
 int n,x;
 printf("Enter Value of X and N:");
 scanf("%d %d",&x,&n);
 printf("\nAnswer of x^n/n!:%.2lf",compute(x,n));
}

