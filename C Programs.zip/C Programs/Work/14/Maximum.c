#include<stdio.h>
#include<conio.h>

int max(int arr[],int size)
{
   
    int i;
    int max=arr[0];

    for(i=0;i<size;i++)
    {
        if(arr[i]>=max)
        {
            max=arr[i];
        }
    }
    return max;
}

int min(int arr[],int size)
{
     int i;
    int min=arr[0];

    for(i=0;i<size;i++)
    {
        if(arr[i]<=min)
        {
            min=arr[i];
        }
    }
    return min;
}


int main()
{

  int arr[]={1,2,3,2,4,5,6,3,1,7,9,7,11,0};
  int size=sizeof(arr)/sizeof(arr[0]);
  printf("Max:%d",max(arr,size));
   printf("\nMin:%d",min(arr,size));
    
  
}