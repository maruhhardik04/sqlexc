#include<stdio.h>
#include<conio.h>

int main()
{
	int arr[10],j,i,n,minptr,maxptr,*min,*max;
	printf("Enter the size of an array : ");
	scanf("%d",&n);

	printf("Enter the elements in array : ");
	for(i=0;i<n;i++)
	{
		scanf("%d",&arr[i]);
	}
	maxptr =arr[0];
	max=&arr[0];

	for(i=0;i<n;i++)
	{
		if(*max >= maxptr)
		{
			maxptr = *max;

		}
		max++;
	}
	 minptr = arr[0];
	 min=&arr[0];

	for(j=0;j<n;j++)
	{
		if(*min <= minptr)
		{
			minptr=*min;

		}

		min++;
	}
	 printf("\nThe maximum number in array is : %d",maxptr);
	printf("\nThe minimum number in array is : %d",minptr);

	getch();
	return 0;
}