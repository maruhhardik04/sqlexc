#include<stdio.h>

int main()
{
    int arr[5]={1,2,3,4,5};
    int sum=0;
    int *p;
    p=arr;

    for(int i=0;i<5;i++)
    {
        sum+=*p;
        p++;
    }
    
    printf("Sum is:%d",sum);
    



}