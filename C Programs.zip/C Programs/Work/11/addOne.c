#include<stdio.h>

void addOne(int *ptr)
{
    (*ptr)++;
}

int main()
{
    int *p,a=10;
    p=&a;
    (*p)++;
    //addOne(p);
    printf("%d %d",p,*p);
}