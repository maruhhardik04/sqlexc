#include<stdio.h>

int main() {
      int num;
     for(int i=1;i<=5;i++)
     {  
        for(int j=5;j>=i;j--)
        {   
              printf(" ");
        }
        for(int k=1;k<=i;k++)
        {
              printf("*");
        }
        for(int l=1;l<=i-1;l++)
        {
              printf("*");  
        }
       printf("\n");
      }
      return 0;
}