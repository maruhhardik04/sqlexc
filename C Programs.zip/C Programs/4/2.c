#include<stdio.h>

int main(int argc, char const *argv[])
{
    
    for (int i = 1,j = 10; i < 5, j > 5; i++,j--)
    {
        printf(" %d %d",i,j);
    }
    

    return 0;
}
