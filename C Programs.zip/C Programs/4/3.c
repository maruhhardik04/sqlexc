#include<stdio.h>

int Fac(int n)
{
    if(n>=1)
    {
        return n * Fac(n-1);
    }
    else
    {
        return 1;
    }
    
    
}

int main(int argc, char const *argv[])
{
    int num;
    
    printf("Enter Number:");
    scanf("%d",&num);

    // for (int i = num; i>1; i--)
    // {
    //     fac *= i;
    // }
    printf("Factorial of %d is %d ",num,Fac(num));
    


    return 0;
}
