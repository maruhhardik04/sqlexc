#include<stdio.h>

int main(int argc, char const *argv[])
{
    
    int i=1;
    printf("Printing 1 to 10 Using While loop\n");
    while (i<=10)
    {
        printf(" %d ",i);
        i++;
    }
    printf("\nPrinting 1 to 10 Using Do While loop\n");
    i=1;
    do
    {
        printf(" %d ",i);
        i++;
    } while (i<=10); 
    
    printf("\nPrinting 1 to 10 Using For loop\n");


    for (i = 1; i <= 10; i++)
    {
       printf(" %d ",i);
    }
    

    return 0;
}
