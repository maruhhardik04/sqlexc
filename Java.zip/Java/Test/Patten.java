import java.util.Scanner;

public class Patten {
    
    public static void main(String[] args) {
        
       Scanner sc = new Scanner(System.in); 
       System.out.print("Enter Number of Elements:");
       int arraySize=sc.nextInt();
       
        int inputIntegerArray[]=new int[arraySize];

        System.out.print("Enter values:");

       for (int i = 0; i < arraySize; i++) {
            inputIntegerArray[i]=sc.nextInt();           
       }
       
       PrintGraphPattern(inputIntegerArray,arraySize);
    }

    public  static void PrintGraphPattern(int inputIntegerArray[],int arraySize)
    {
        System.out.print(" ");   
        for (int i = 0; i < arraySize; i++) {
                System.out.print(i);
            }
            System.out.println();
            for (int i = 0; i < arraySize; i++) {
                System.out.print(i);
                for (int j = 0; j < arraySize; j++) {
                    
                    if(inputIntegerArray[i]==j)
                    {
                        System.out.print("*");
                    }
                    else
                    {
                        System.out.print(" ");
                    }
                }
                System.out.println();
            }
    }
}
