class maxnumber
{
    public static void main(String[] args) {

        int a=10,b=50,c=30;
        // String count = Integer.toString(a);
        
        if(a>=b && a>=c)
        {
            System.out.println("a is Max");
        }
        else
        {
            if(b>=c)
            {
                System.out.println("b is Max");
            }
            else
            {
                System.out.println("c is Max");
            }
        }

    }
}