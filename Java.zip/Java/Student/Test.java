package Student;

import java.util.Scanner;

class Test extends Student1{
    
    
    public static void main(String[] args) {
        int r_no,marks;
        String name,gender;
        Scanner sc=new Scanner(System.in);    
      
        System.out.println("Enter Name:");
        name=sc.nextLine();
        System.out.println("Gender:");
        gender=sc.nextLine();
        System.out.println("Enter Roll Number:");
        r_no=sc.nextInt();
        System.out.println("Enter Marks:");
         marks=sc.nextInt();
         sc.close();
        
         System.out.println();
         
        Student1 s1=new Student1();
         s1.display();
        System.out.println();
        Student1 s2=new Student1(r_no,marks,name,gender);
        s2.display();

        Student1.objectCount();

    }

}