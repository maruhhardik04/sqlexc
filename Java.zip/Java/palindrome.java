class palindrome{
    public static void main(String[] args) {
        
    }
}