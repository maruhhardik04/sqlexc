
public class Outer {



    
    public class Inner{
    
        

        int min(){
            return 0;
        };
        
        int max(){
            return 0;
        };
        
        int avg(){
            return 0;
        };
    }
    
}