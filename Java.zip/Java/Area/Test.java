package Area;
import java.util.Scanner;
public class Test extends Rectangle{
    
    public static void main(String[] args) {
        
         Scanner scanner  = new Scanner(System.in);
         int length,width;
         System.out.print("Enter Length and Width:");
         length=scanner.nextInt();
         width=scanner.nextInt();
         scanner.close();

         Rectangle r1=new Rectangle();
         r1.Area();
         r1.Area(4,5);
          System.out.println();
          Rectangle  r2 = new Rectangle(length,width);
          r2.Area();
         System.out.println();
          Rectangle r3=new Rectangle(r2);
          r3.Area();

         System.out.println(); 
         Circle c1 = new  Circle(6);
         c1.areaOfCircle();
         Circle c2 = new  Circle(7);
         c2.areaOfCircle();
        System.out.println("Total object Created:"+Rectangle.count);

    }


}
