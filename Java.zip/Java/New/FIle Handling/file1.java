import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;


/**
 * file1
 */
public class file1 {

    public static void main(String[] args) throws IOException {
        

        File file=new File("1.txt");
        Scanner scanner=new Scanner(file);
        

        while (scanner.hasNextLine()) {
            System.out.println(scanner.nextLine());
        }

        scanner.close();
       // file.createNewFile();
       
    }
    
}