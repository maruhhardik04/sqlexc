final class Demo{

}

class Demo1{

     final  void print(double input)
    {

        System.out.println(input);
    }
}

public class EX30 extends Demo1{
    public static void main(String[] args) {
        final double PI=3.14;
        // PI=3.15;
        Demo1 demo1 = new Demo1();
        demo1.print(PI);
    }

    //  void print(double input)
    // {

    // }
    
}
