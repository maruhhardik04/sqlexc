import java.util.Scanner;

public class EX28 {
    
    public static void main(String[] args) {
        
        Scanner sc =new Scanner(System.in);
        System.out.println("Enter A String:");
        String aString=sc.nextLine();
        sc.close();

        if(aString.equals(aString.toLowerCase()))
        {
            System.out.println("String is in LowerCase.");
            System.out.println("String:"+aString.toUpperCase());
        }
        else if(aString.equals(aString.toUpperCase()))
        {
            System.out.println("String is in UpperCase");
            System.out.println("String:"+aString.toLowerCase());
        }
        else{
             System.out.println("String is Contain UpperCase And LowerCase Both.");
                    
         }
    }
}
