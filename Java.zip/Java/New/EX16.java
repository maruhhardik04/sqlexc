public class EX16{
    
    public static void main(String[] args) {
    
        Byte byte1=new Byte("10");
        Short short1=new Short("20");
        Integer aInteger = new Integer(3);
        Long long1=new Long(40);
        Float floatobj=new Float(50.0F);
        Double double1= new Double(60.0D);
        Character character=new Character('a');
        Boolean b=new Boolean(true);       
        System.out.println(byte1);
        System.out.println(short1);
        System.out.println(aInteger);
        System.out.println(long1);
        System.out.println(floatobj);
        System.out.println(double1);
        System.out.println(character);
        System.out.println(b);
    }
}
