public class Example {
    

    public static void main(String[] args) {
        
                new Producer().start();
                new Consumer().start();
               

    }


}

class Method
{
    private int n;
    synchronized void get()
    {
        System.out.println("Got:"+n);
    }

    synchronized void put(int n){
        this.n=n;
        System.out.println("Put:"+n);
    }

}


class Producer extends Thread{
        Method method =new Method();

        @Override
        public void run() {
        
            int i=0;
            while (true) {
                method.put(i++);
            }

        }

}



class Consumer extends Thread{

    Method method =new Method();

        @Override
        public void run() {
           while (true) {
               method.get();
           }
        }

}
