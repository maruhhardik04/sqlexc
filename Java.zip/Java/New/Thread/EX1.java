import java.util.*;

public class EX1 extends Thread{

    public static void main(String[] args) {
        

        
        EX1 thread1 = new EX1();
        EX1 thread2 = new EX1();
        EX1 thread3 = new EX1();
        
        thread1.setPriority(MAX_PRIORITY);
        thread2.setPriority(NORM_PRIORITY);
        thread3.setPriority(MIN_PRIORITY);


        thread1.setName("thread1");
        thread2.setName("thread2");
        thread3.setName("thread3");

        thread1.start();
        thread2.start();
        thread3.start();


        
        System.out.println("This code is outside of the thread");

    }

    public void run(){

        try {   
            System.out.println(Thread.currentThread().getName());            
        } catch (Exception e) {

            System.out.println(e.getMessage());
        }
    }



}
