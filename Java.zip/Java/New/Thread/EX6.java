class Account extends Thread{

    private static int Balance=1000;
    private int b;

    public Account(int b) {
            this.b=b;
    }

    synchronized private void width()
    {
        if(this.b>Balance)
        {
            System.out.println("Balance is no suff");
        }
        else{
            Balance -= this.b;
            System.out.println(Balance);
        }
        
    }


    @Override
      public void run() {
        
        width();

    }

    public static int getBalance() {
        return Balance;
    }

}


public class EX6 {

    public static void main(String[] args) {
        


        Account account=new Account(300);
        account.setPriority(10);
        
        Account account2 = new Account(800);
        account2.setPriority(1); 
        
        account.start();
        account2.start();
      
        
        

    }
}