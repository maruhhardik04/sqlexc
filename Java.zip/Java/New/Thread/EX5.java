
class NewThread extends Thread{

    private String _Name;
    private int limit;

    public NewThread(String Name,int limit) {

    this.set_Name(Name);
    this.setLimit(limit);
    
    }


    @Override
    public void run() {
       
        try {
            for(int i=1;i<=this.getLimit();i++)
            {
                System.out.println(this.get_Name());
            }
        } catch (Exception e) {
            System.err.println(e.getMessage());    
        }
        
    }

        public void set_Name(String _Name) {
                this._Name = _Name;
         }

        public String get_Name() {
            return _Name;
         }

        public void setLimit(int limit) {
            this.limit = limit;
        }

        public int getLimit() {
            return limit;
        }


}


public class EX5 {
    

    public static void main(String[] args) {
        
        NewThread newThread=new NewThread("A",20);
        NewThread newThread2=new NewThread("B",30);
        NewThread newThread3=new NewThread("C",15);

        newThread.start();
        newThread2.start();
        newThread3.start();


    }

}
