class OddThread extends Thread{


    @Override
    public void run() {
      
        for (int i = 0; i <= 50; i++) {
            if(i%2!=0) System.out.println("\t"+i);
           
        }   
         
    }
}

class EvenThread extends Thread
{
    @Override
    public void run() {

            for (int i = 0; i <= 50; i++) {
                if(i%2==0) System.out.println(i);
            }
    }

}



public class EX4 extends Thread{
    
public static void main(String[] args) {
    OddThread oddThread=new OddThread();
    EvenThread evenThread=new EvenThread();
    oddThread.start();
    evenThread.start();
}


}
