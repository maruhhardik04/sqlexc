package EX23;


public class EX23 {

    public static void main(String[] args) {
        
       Rectangle r=new Rectangle(5.5,9.4);
       r.area();
       Circle c=new Circle(5.2);
       c.area();
       Triangle t=new Triangle(3, 5);
       t.area();


    }
    
}



