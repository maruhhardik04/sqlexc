package EX23;

public abstract class Shape {
    
    public abstract void area();

}
