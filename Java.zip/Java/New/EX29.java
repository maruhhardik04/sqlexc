

public class EX29 {

    public static void main(String[] args) {

        String string="Hello";
        System.out.println("Length of "+string+" is:"+string.length());
        System.out.println(string.substring(2));
        System.out.println(string.concat(" World"));
        System.out.println(string.equals("Hello"));
        System.out.println("Replace of "+string+" is:"+string.replace('l', 'a'));
        System.out.println("Compare:"+string.compareTo("He"));
        
    }
}
