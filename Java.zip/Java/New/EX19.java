

public class EX19 {
    
    public static void main(String[] args) {
        
          Savings s1=new Savings(123456789, 10000, 7);
          s1.deposit(500);
          s1.checkBalance();


        Current c1=new Current(04123456, 2000, 1000);
         c1.withdraw(500);
         c1.checkBalance();
         c1.withdraw(1500);
         c1.checkBalance();
         System.out.println(" overdraftLimit:"+c1.overdraftLimit);
         c1.withdraw(900);
         c1.checkBalance();
         System.out.println(" overdraftLimit:"+c1.overdraftLimit);
         c1.withdraw(110);
        c1.checkBalance();


    }


}

class Account{

     int accountNo,balance;
    
     
     Account(int accountNo,int balance)
     {
         this.accountNo=accountNo;
         this.balance=balance;
     }
   

    protected void checkBalance()
    {
       System.out.println("Account:"+this.accountNo+" Balance is:"+this.balance); 
        
    }

} 
 class Savings extends Account{

    int interestRate;

    Savings(int accountNo,int balance,int interestRate){
        super(accountNo, balance);
        this.interestRate=interestRate;
     }



    protected void deposit(int balance)
    {
        super.balance+=balance;
    }

    protected void withdraw(int balance)
    {
      super.balance-=balance;
    }



}
 class Current extends Account{



         int overdraftLimit;


         
        Current(int accountNo,int balance,int overdraftLimit){
           super(accountNo, balance);
           this.overdraftLimit=overdraftLimit;
          }

   

    protected void deposit(int balance)
    {
         super.balance+=balance;
    }

    protected void withdraw(int balance)
    {

        if(balance<=super.balance)
        {
            super.balance-=balance;
        }
        else{
                if(balance<=this.overdraftLimit)
                {
                    System.out.println("Your OverdrafLimit is Reach");
                }
                else{
                    this.overdraftLimit-=balance;
                }
        }
    }



}
