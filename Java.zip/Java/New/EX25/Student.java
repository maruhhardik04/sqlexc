

import java.util.Arrays;

public class Student {
    
        private String Name;
        private int rollNo;
        private int marks[];
        
        public Student(String Name,int rollNo,int[] marks) {
            this.Name=Name;
            this.rollNo=rollNo;
            this.marks=marks;
        }
    

        public void showStudentDetails()
        {
            System.out.println("RollNo:"+this.rollNo);
            System.out.println("Name:"+this.Name);
            System.out.println("Marks:"+Arrays.toString(marks));
        }

        public int[] getMarks()
        {
            return marks;
        }
        

        


        

}
