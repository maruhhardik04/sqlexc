package Exam;

import student.Student;

public class Result {
 
        
public static void main(String[] args) {
    
    
    int marks[]={50,80,90,60,70};
    Student s=new Student("Hardik",1, marks);
    s.showStudentDetails();
    int total=0;
    for (int i : s.getMarks()) {
        total+=i;
    }
    System.out.println("Total of Marks:"+total);
    System.out.println("Avg:"+(total/marks.length));


}

}
