package ColEx;

import java.util.ArrayList;

/**
 * Employee
 */
public class Employee {

    
    private int basic_sal,emp_code; 
    private String  emp_name;

    public Employee(int emp_code,int basic_sal,String emp_name) {
        this.setBasic_sal(basic_sal);
        this.setEmp_code(emp_code);
        this.setEmp_name(emp_name);
    }

    public int getEmp_code() {
        return emp_code;
    }

    public void setEmp_code(int emp_code) {
        this.emp_code = emp_code;
    }

    public int getBasic_sal() {
        return basic_sal;
    }

    public void setBasic_sal(int basic_sal) {
        this.basic_sal = basic_sal;
    }

    public String getEmp_name() {
        return emp_name;
    }

    public void setEmp_name(String emp_name) {
        this.emp_name = emp_name;
    } 
    
   
    public double getGrossSalary()
    {
        return (getBasic_sal()+(.2*getBasic_sal())+(.3*getBasic_sal()));
    }
    
    
    public static void main(String[] args) {
        

        ArrayList<Employee> Emp = new ArrayList<Employee>();
        Emp.add(new Employee(1, 10000, "Hardik"));
        Emp.add(new Employee(2, 20000, "Yash"));
        Emp.add(new Employee(3, 21225, "Harshit"));
        Emp.add(1, new Employee(4, 30000, "Rusik"));



            for (Employee employee : Emp) {
                System.out.println();
                System.out.println("Emp_code:"+employee.getEmp_code());
                System.out.println("Name:"+employee.getEmp_name());
                System.out.println("Basic_Salary:"+employee.getBasic_sal());
                System.out.println("Gross_Salary:"+employee.getGrossSalary());
                System.out.println();
            }



    }


}