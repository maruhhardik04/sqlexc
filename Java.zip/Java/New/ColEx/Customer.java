package ColEx;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Customer {

    private int billNo,itemUnitPrice[],itemCount[];
    private String custMobileNo,itemName[];

    
    public Customer() {
        super();
    }

    public Customer(int billNo, String custMobileNo, String[] itemName,int[] itemUnitPrice,int[] itemCount) {
         
    
        this.setBillNo(billNo);
        this.setCustMobileNo(custMobileNo);
        this.setItemName(itemName);
        this.setItemUnitPrice(itemUnitPrice);
        this.setItemCount(itemCount);
        

    }





    public int getBillNo() {
        return billNo;
    }



    public String[] getItemName() {
        return itemName;
    }



    public void setItemName(String itemName[]) {
        this.itemName = itemName;
    }



    public String getCustMobileNo() {
        return custMobileNo;
    }



    public void setCustMobileNo(String custMobileNo) {
        this.custMobileNo = custMobileNo;
    }



    public int[] getItemCount() {
        return itemCount;
    }



    public void setItemCount(int itemCount[]) {
        this.itemCount = itemCount;
    }



    public int[] getItemUnitPrice() {
        return itemUnitPrice;
    }



    public void setItemUnitPrice(int itemUnitPrice[]) {
        this.itemUnitPrice = itemUnitPrice;
    }


    public void setBillNo(int billNo) {
        this.billNo = billNo;
    }

    public int getTotalPrice()
    {   int totalPrice=0;
        
        for (int i = 0; i < itemCount.length; i++) {
            totalPrice+= (itemUnitPrice[i]*itemCount[i]);
        }

        return totalPrice;
    }
    



    public static void main(String[] args) {
        

        Scanner sc= new Scanner(System.in);

        Customer customer=new Customer();
        customer.getCustMobileNo();

        HashMap<String,Customer> map = new HashMap<String,Customer>();
        map.put("0123456789",new Customer(1,"0123456789",new String[]{"ice cream","coconut","sandwich",},new int[]{10,10,10},new int[]{1,2,1}));
        map.put("7127893787",new Customer(2,"7127893787",new String[]{"burger","cold drink"},new int[]{30,40},new int[]{1,2}));
        map.put("123456789",new Customer(3,"123456789",new String[]{"ice cream","cold drink","sandwich",},new int[]{30,40,10},new int[]{1,2,3}));

        

        System.out.println("Display HashMap");
        System.out.println();



        

        for (Map.Entry<String, Customer> m: map.entrySet()) {

                

                System.out.println();
                System.out.println("Key:"+m.getKey());
                System.out.println("Item No:"+m.getValue().getBillNo());
                System.out.println("Cust Mobile No:"+m.getValue().getCustMobileNo());
                System.out.println("Item Name:"+Arrays.toString(m.getValue().getItemName()));
                System.out.println("Item Unit Price:"+Arrays.toString(m.getValue().getItemUnitPrice()));
                System.out.println("Item Count:"+Arrays.toString(m.getValue().getItemCount()));
                System.out.println("Toal Price:"+m.getValue().getTotalPrice());
                System.out.println();
        }

        System.out.print("Enter a Key:");
        String Key=sc.nextLine();
        



        for (Map.Entry<String, Customer> m: map.entrySet()) {


            if (m.getKey().equals(Key)) {

                
            System.out.println();
            System.out.println("Key:"+m.getKey());
            System.out.println("Item No:"+m.getValue().getBillNo());
            System.out.println("Cust Mobile No:"+m.getValue().getCustMobileNo());
            System.out.println("Item Name:"+Arrays.toString(m.getValue().getItemName()));
            System.out.println("Item Unit Price:"+Arrays.toString(m.getValue().getItemUnitPrice()));
            System.out.println("Toal Price:"+m.getValue().getTotalPrice());
            System.out.println("Item Count:"+Arrays.toString(m.getValue().getItemCount()));
            System.out.println();
            }
        }
    }
}




