class fibonachi{
    public static void main(String[] args) {
        
        int res,a=0,b=1;
        
            System.out.print(a + " " + b);
        for(int i=2;i<10;i++)
        {
            res=a+b;
            System.out.print(" "+res);
            a=b;
            b=res;
        }

    }
}