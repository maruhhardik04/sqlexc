
import java.lang.Math;
class arm{
    public static void main(String[] args) {
        
        // Scanner sc = new Scanner(System.in);
        // System.out.print("Enter a number:");
       // int a = sc.nextInt();
       int a=153;
       String abc=Integer.toString(a);
        int tem=1;
        while(a!=0)
        {
            a/=10;
            double power=Math.pow(tem,abc.length());
            tem=tem*10+(int)power;
        }
        if(tem==Integer.parseInt(abc))
        {
            System.out.println("Armstrong");
        }

        


    }
}