<?php
require_once "config.php";


$sql="Select * from user_master";
$res=$conn->query($sql);

    if($res->num_rows>0)
     {
      $re["users"]=array();
      while($row = $res->fetch_assoc())
      {
         $e=array(
             "id"=>$row['id'],
             "fname"=>$row['fname'],
             "mname"=>$row['mname'],
             "lname"=>$row['lname']
         );
         array_push($re["users"],$e);
      }
      echo json_encode($re);
    }
?>