<?php

require 'config.php';

$fname=$_REQUEST['fname'];
$mname=$_REQUEST['mname'];
$lname=$_REQUEST['lname'];


$sql="insert into user_master(fname,mname,lname) values('$fname','$mname','$lname')";

  if($conn->query($sql) === TRUE)
  {
      echo "Record Inserted.";
}
  else
  {
      echo "Error".$conn->error;
  }
$conn->close();

?>