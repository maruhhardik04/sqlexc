<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
    <script>

        const xmlhttp = new XMLHttpRequest();
           function fun()
           {
               var fname=document.getElementById("fname").value;
               var mname=document.getElementById("mname").value;
               var lname=document.getElementById("lname").value;
              
                xmlhttp.onload = function() {
                    document.getElementById("mymsg").innerHTML = this.responseText;
                }
                xmlhttp.open("GET", "insert.php?fname=" + fname+"&mname="+mname+"&lname="+lname);
                xmlhttp.send();
           }
                //get data from php

                    document.addEventListener('DOMContentLoaded', function() {
                        let tbody=document.querySelector('tbody');
                        console.log(tbody);
                        $.get('select.php',(data)=>{
                           let myData=JSON.parse(data);
                           //console.log(myData['users'])
                           myData['users'].forEach(element => {
                                let row=document.createElement('tr');

                                let row_data=document.createElement('td');
                                row_data.innerHTML=element['id'];
                                row_data.hidden=true;

                                let row_data1=document.createElement('td');
                                row_data1.innerHTML=element['fname'];
                
                                let row_data2=document.createElement('td');
                                row_data2.innerHTML=element['mname'];

                                let row_data3=document.createElement('td');
                                row_data3.innerHTML=element['lname'];   
                                
                                let row_data4=document.createElement('td');

                                row.appendChild(row_data);
                                row.appendChild(row_data1);
                                row.appendChild(row_data2);
                                row.appendChild(row_data3);
                                tbody.appendChild(row);
                                
       
                        });
                        })
                        
            
                });
    </script>
</head>
<style>
table, th, td {
  border:1px solid black;
}
</style>
<body>
<form>   
        <span>First Name:</span><input type="text" name="fname" id="fname" required><br>
        <span>Middle Name:</span><input type="text" name="mname" id="mname" required><br>
        <span>Last Name:</span><input type="text" name="lname"  id="lname" required><br>
        <input type="button" onclick="fun()" value="Insert">
    </form>
    <div id="mymsg"></div>
    <table style="width:100%">
    <thead>
        <tr>
            <!-- <th>ID</th> -->
            <th>First Name</th>
            <th>Middle Name</th>
            <th>Last Name</th>
            <!-- <th>Update</th>
            <th>Delete</th> -->
            </tr>
    </thead>  
    <tbody>

    </tbody>
    </table>

</body>
</html>