<?php require 'config.php'?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
</head>
<style>
table, th, td {
  border:1px solid black;
}
</style>
<body>
    <form action="insert.php" method="post">
        <br>
        <span>First Name:</span><input type="text" name="fname" id="fname" required><br>
        <span>Middle Name:</span><input type="text" name="mname" required><br>
        <span>Last Name:</span><input type="text" name="lname" required><br>
        <input type="submit"  value="Insert">
    </form>
    
    <table style="width:100%">
          <tr>
            <th>First Name</th>
            <th>Middle Name</th>
            <th>Last Name</th>
            <th>Update</th>
            <th>Delete</th>
         </tr>
    <?php
        $sql="select * from user_master";
        $result=$conn->query($sql);
        if($result->num_rows>0)
        {
            while($row = $result->fetch_assoc())
            {?>
        <tr>
            <td><?=$row["fname"]?></td>
            <td><?=$row["mname"]?></td>
            <td><?=$row["lname"]?></td>
            <td><a href="update.php?id=<?=$row["id"]?>">Update</a></td>
            <td><a href="delete.php?id=<?=$row["id"]?>">Delete</a></td>
        </tr>
            <?php }
        }
    ?>
    </table>
</body>
</html>