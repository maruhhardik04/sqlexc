<?php
    require_once "config.php";
    $uid=$_GET['id'];
    $sql="select * from user_master where id=$uid";
    $result=$conn->query($sql);
    $row=$result->fetch_assoc();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit</title>
</head>
<body>        

<form method="post">
        <br>
        <span>First Name:</span><input type="text" name="fname" value="<?=$row['fname']?>" required><br>
        <span>Middle Name:</span><input type="text" name="mname" value="<?=$row['mname']?>"required><br>
        <span>Last Name:</span><input type="text" name="lname" value="<?=$row['lname']?>" required><br>
        <input type="submit" name="Update" value="Update">
    </form>
    <?php

if(isset($_POST['Update'])) 
{
    
$fname=$_POST['fname'];
$mname=$_POST['mname'];
$lname=$_POST['lname'];

$sql="UPDATE user_master set fname='$fname',mname='$mname',lname='$lname' where id=$uid";
$res=$conn->query($sql);
if($res>=0)
{    
    header("Location:index.php");
}
else
{
    echo $conn->error;
}


}


?>
</body>
</html>    

