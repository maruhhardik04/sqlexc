<?php

require 'config.php';

$fname=$_POST['fname'];
$mname=$_POST['mname'];
$lname=$_POST['lname'];


$sql="insert into user_master(fname,mname,lname) values('$fname','$mname','$lname')";

  if($conn->query($sql) === TRUE)
  {
      echo "Record Inserted.";
      header("Location: index.php");
}
  else
  {
      echo "Error".$conn->error;
  }
$conn->close();

?>