<?php
    $conn = new mysqli("localhost","root","","eco");
    
if($conn->connect_error)
{
    die("Connection failed: " . $conn->connect_error);

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Upload In Database</title>
</head>
<body>
        <form action="" method="post" enctype="multipart/form-data">
            <label for="fileUpload">
                Select File:
                <input type="file" name="fileUpload" accept="image/JPEG">
            </label>
            <input type="submit" name="submit" value="Upload">
        </form>
        <?php
                $sql="select * from images";
                $res=$conn->query($sql);?>
                <table border='1'>
                        <thead >
                            <th>
                                ID
                            </th>
                            <th>
                                Name
                            </th>
                            <th>
                                Image
                            </th>
                        </thead>
                <?php
                while($row=$res->fetch_object())
                {
                   
                ?>
                    <tbody>
                        <tr>
                            <td><?=$row->id?></td>
                            <td><?=$row->name?></td>
                            <td>
                                <?php
                                 
                                //    echo $image=base64_encode($row->image);
                                    // echo '<img height="100px" src="data:image/jpeg;base64,'.base64_encode($row->image).'"/>';
                                ?>
                                 <img height="100px" src="data:image/JPEG;base64,<?php echo base64_encode($row->image) ?>"/>
                                </td>
                        </tr>
                    </tbody>    
                <?php 

                }
        ?>
</body>
</html>

<?php

    if(isset($_POST['submit']))
    {
            if(isset($_FILES['fileUpload'])){
                $name="".time();
                $fp=addslashes(file_get_contents($_FILES['fileUpload']['tmp_name']));
                $sql="insert into images values('null','{$name}','{$fp}');";
                $conn->query($sql);
            }
    }

?>
