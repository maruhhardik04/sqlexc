<?php


//  call By references
function f1(&$a)
{
    $a="Hi ".$a;
    return $a;
}

$a="Hardik";
$ans=f1($a);
echo $a;


echo "<br><br>";


// call By Value
$a="Hardik";
function f2()
{
    
    echo $GLOBALS['a'];
    $a="Shadow";
    $a="Hi ".$a;
    echo "<br>".$a;
    // return $a;
}

echo f2();



?>