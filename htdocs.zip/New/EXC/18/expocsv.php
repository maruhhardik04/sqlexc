<?php

require 'config.php';



$field =array();


$sql="select * from trains";   
$res=$conn->query($sql);



if($res->num_rows>0)
{
    while($row=$res->fetch_assoc())
    {
        $field[]=$row;
    }    

}

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=Trains.csv');


$output = fopen('php://output', 'w');

fputcsv($output,array('Trainno','Code','Name','Type','Starting_city','Destinaion_city','Flag'));

if(count($field)>0){
    foreach($field as $row)
    {
        fputcsv($output,$row);
    }
}

?>