<?php

$conn= new mysqli("localhost","root","","id17621117_railway");


if ($conn->connect_errno) {
    die("Connection failed: " . $conn->connect_error);
  }

?>