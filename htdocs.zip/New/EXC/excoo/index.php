<?php

    if($_POST)
    {
        $key=$_POST["key"];
        $value=$_POST["value"];

        setcookie($key,$value,time()+86400);
    }
    

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
</head>
<body>
    <form  method="post">
        <lable>Key:
            <input type="text" name="key" required>
        </label>
        <br>
        <label>Value:   
            <input type="text" name="value" required>
        </lable>
        <input type="submit" value="Set  Cookie">
</form>
br
<a href="./showCookie.php">Cookies</a>
</body>
</html>