<?php

        $conn=new mysqli("localhost","root","","cart");

        <?php
    
        function update_data($id)
       {
           echo $id;
       }

?>

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script>

            function update(id) {
            
            
                
            }

    </script>
    
</head>
<body>
<table class="table display" >
               <thead>
                 <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Quantity</th>
                    <th>Price</th>
                    <th>Edit</th>
                    <th>Delete</th>
                 </tr>
                </thead>
                <tbody>
                    <?php
                        $sql="SELECT * FROM `product_catalog`";
                        $res=$conn->query($sql);

                        if($res->num_rows>0)
                        {
                            while($row=$res->fetch_object()){
                    ?>
                    <tr>
                        <td><?=$row->id?></td>
                        <td><?=$row->name?></td>
                        <td><?=$row->qty?></td>
                        <td><?=$row->price?></td>
                        <td>
                           <input type="button" value="Update" onclick="update(<?=$row->id?>);">
                        </td>
                        <td>    
                        <input type="button" value="Delete" onclick="delete(<?=$row->id?>);">
                        </td>
                    </tr>
                    <?php
                        }
                    }
                    ?>
                </tbody>
        </table>  
</body>
</html>