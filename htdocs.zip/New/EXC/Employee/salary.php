<?php

$name=$_POST['name'];
$mnumber=$_POST['mnumber'];
$email=$_POST['email'];
$bsalary=$_POST['salary'];


$da=($bsalary*20)/100;
$hra=($bsalary*10)/100;



$pf=($bsalary*12)/100;
$pt=($bsalary*2)/100;

$salary=$bsalary+$da+$hra-$pf-$pt;


// echo "Employees Name:".$name."<br>";
// echo "Mobile Number:".$mnumber."<br>";
// echo "Email:".$email."<br>";
// echo "Basic Salary:".$bsalary."<br>";
// echo "Total Earnings:".($bsalary+$da+$hra)."<br>";
// echo "Total Deductions:".($pf+$pt)."<br>";
// echo "Net Pay: ".$salary."<br>";



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Salary Slip</title>
</head>
<style>
    table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}
</style>
<body>
            <table  Cellpadding = "6" Cellspacing = "6">
            <tr>
                <th Colspan = "6" Align = "Center">
                    Employee Salary Slip
                </th>
            </tr>
            <tr>
                <td Colspan = "6">
                    Name:<?=$name?><br>
                    Email:<?=$email?><br>
                    Mobile Number:<?=$mnumber?>  
                </td>   
            </tr>
            <tr>
                <th Colspan = "3">
                    Earnings
                </th>
                <th Colspan = "3">
                     Deductions
                </th>
            </tr>
            <tr>
                <td Colspan = "3">
                    Basic Salry:<?=$bsalary?><br>
                    DA:<?=$da?><br>
                    HRA:<?=$hra?>
                </td>
                <td Colspan = "3">
                    PF:<?=$pf?><br>
                    PT:<?=$pt?><br>
                </td>
            </tr>
            <tr>
                <td colspan="3">
                Total Earnings:<?=($bsalary+$da+$hra)?>
                </td>
                <td colspan="3">
                    Total Deductions:<?=($pf+$pt)?>
                </td>
            </tr>
            <tr>
                <td colspan="6">
                      Net Pay:<?=$salary?>
                </td>
            </tr>
           
            </table>
</body>
</html>