<?php
    session_start();
$conn=new mysqli("localhost","root","","cart");
$_SESSION['cart']=array();



?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.22/css/jquery.dataTables.css">
    
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.js"></script>
    
    
    <script>         

$(document).ready( function () {
    $('#myTable').DataTable();
} );
  </script>
    
    <title>Product Catalog</title>
</head>
<body>
    <div class="container">
        <table class="display" id="myTable">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Quantity</th>
                    <th>Price</th>
                    <th>Purchase Quantity</th>
                    <th>Add to Cart</th>
                </tr>
            </thead>
            <tbody>
                <?php
                        $sql="SELECT * FROM `product_catalog`";
                        $res=$conn->query($sql);
                        
                        if($res->num_rows>0)
                        {
                            while($row=$res->fetch_object()){
                                ?>
                    <tr>
                        <td><?=$row->id?></td>
                        <td><?=$row->name?></td>
                        <td><?=$row->qty?></td>
                        <td><?=$row->price?></td>
                        <form  method="post" class="form-inline">
                            <td>
                                <input type="number" name="pqty" value="1" max=<?=$row->qty?> min=1>
                            </td>
                            <td>
                                
                            <input type="hidden" name="id" value=<?=$row->id?>>
                            <input type="hidden" name="name" value=<?=$row->name?>>
                            <input type="hidden" name="qty" value=<?=$row->qty?>>
                            <input type="hidden" name="price" value=<?=$row->price?>>
                            <input type="hidden" name="action" value="ADD">
                            <input type="submit" name="add_to_cart" value="Add To Cart" class="btn btn-success">
                            
                        </td>
                    </form>
                </tr>
                <?php
                        }
                    }
                    ?>
                </tbody>
            </table>  
        </div>
    </body>
    </html>
    
    <?php   
        if($_POST)
        {
            if($_POST['action'] && $_POST['action'] == "ADD")
            {
                $cart = array("id"=>$_POST['id'],"name"=>$_POST['name'],"qty"=>$_POST['qty'],"price"=>$_POST['qty'],"pqty"=>$_POST['pqty']);
                array_push($_SESSION['cart'],$cart);
                print_r($_SESSION['cart']);
            
                if($_SESSION['cart'][0]['id']==$_POST['id'])
                {
                    echo "avl";
                }
            }
        }

        


?>
