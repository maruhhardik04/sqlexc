<?php

class Loan
{
    private $capital=0.0;
    private $interest=0.0;
    private $year=0.0;
    private $instalment='';

    function __construct($capital=0.0,$interest=0.0,$year=0.0,$instalment='')
    {
        $this->capital=$capital;
        $this->interest=$interest;
        $this->year=$year;
        $this->instalment=$instalment;
    }


    public function get_capital()
    {
        return $this->capital;
    }


    public function get_interest()
    {
        return $this->interest;
    }

     public function get_year()
    {
        return $this->year;
    }

    public function get_instalment()
    {
        return $this->instalment;
    }


     public function get_info()
    {
        print "Capiatal  $this->capital<br>";
        print "Interest  $this->interest<br>";
        print "Instalment  $this->instalment<br>";
        print "Year  $this->year<br>";

        $this->calc_ins();
       

    }

    private function calc_ins()
    {
        $months=$this->year*12;
        if(strcmp($this->instalment,"Fixed")==0)
        {
            $fixedPayment=$this->capital/ $months;
            $interestRateForMonth=$this->interest/12;


            for ($i=0; $i < $months; $i++) { 
               
                $interestRateForMonth=$this->capital/100 * $interestRateForMonth; 
                $this->capital=$this->capital-$fixedPayment;

                $paymentForMonth=$fixedPayment + $interestRateForMonth;

                $month=$i+1;
                printf("$month payment is %.2f<br>",$paymentForMonth);
            }

        }
        else
        {

            $this->interest=$this->interest / 100;
            $result=$this->interest / 12 * pow(1+$this->interest / 12,$months)/(pow(1+$this->interest/12,$months)-1)*$this->capital;
            printf("Monthly pay is %.2f",$result);
        }

    }


}