<?php

// setcookie("Name","Hardik",time()+86400);



// if(isset($_COOKIE["Name"]))
//     echo $_COOKIE["Name"];
// else
//     echo "Cookie is not set";



   setcookie("Name","",time()-10,"/");
   unset($_COOKIE["Name"]);
   echo "Cookie is Deleted."; 



