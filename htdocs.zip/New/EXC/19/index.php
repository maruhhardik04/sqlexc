<?php require 'config.php'?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
            <form  method="post">
                <input type="search" name="search" placeholder="Search By  Starting city or  Train Type  or  Flag ( W for weekly, D for Daily)">
                <input type="submit" name="submit" value="Search" >
            </form>
            <table border="1">
            <thead>
                    <th>Index</th>
                    <th>Code</th>
                    <th>Name</th>
                    <th>Type</th>
                    <th>Starting_city</th>
                    <th>Destinaion_city</th>
                    <th>Flag</th>
            </thead>
            <tbody>
                <?php
                    
                    if(isset($_POST['submit']))
                    {

                        $str=$_POST['search'];
                        $sql="select * from trains where Starting_city Like '%".$str."' or Type='".$str."' or Flag='".$str."'";
                           
                        
                    }
                    else
                    {
                     $sql="select * from trains";   
                    }
                    $res=$conn->query($sql);
                    if($res->num_rows>0)
                    {
                        while($row=$res->fetch_assoc())
                        {?>
                            <tr>
                                <td><?=$row['Trainno']?></td>
                                <td><?=$row['Code']?></td>
                                <td><?=$row['Name']?></td>
                                <td><?=$row['Type']?></td>
                                <td><?=$row['Starting_city']?></td>
                                <td><?=$row['Destinaion_city']?></td>
                                <td><?=$row['Flag']?></td>
                            </tr>
                        <?php
                        }
                    }
                  
                ?>

                
            </tbody>
            </table>
       

            
   
</body>
</html>