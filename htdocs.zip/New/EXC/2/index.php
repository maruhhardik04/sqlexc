


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
</head>
<body>
    <form action="" method="POST" enctype="multipart/form-data">
        First Name:<input type="text" name="fname"><br>
        Middle Name:<input type="text" name="mname"><br>
        Last Name:<input type="text" name="lname"><br><br>

        Gender:
        Male<input type="radio" name="sex" value="Male" checked>
        Female<input type="radio" name="sex" value="Female"><br><br>

        Date Of Birth <input type="date" name="date"><br><br>

        Email: <input type="email" name="email"><br><br>
        <!-- Mobile Number:<input type="" name="snumber" min="10" max="10"><br><br> -->
        Language:<br>
        t<input type="checkbox" name="Language[]" value="Gujrati">Gujrati<br>
        <input type="checkbox" name="Language[]" value="Hindi">Hindi<br>
        <input type="checkbox" name="Language[]" value="English">English<br><br>  
        City: <select name="City">
                <option value="Jamnagar">Jamnagar</option>
                <option value="Rajkot">Rajkot</option>
        </select><br><br>
        
        Address: <textarea name="address"  cols="40" rows="4"></textarea><br><br>

        Profile Image: <input type="file" name="pimage"><br>

        <input type="submit" value="submit">
    </form>
    <?php
        if(isset($_POST)){

          echo "First Name:".$_POST['fname']."<br>";
          echo "Middle Name:".$_POST['mname']."<br>";
          echo "Last Name:".$_POST['lname']."<br>";
          echo "Gender:".$_POST['sex']."<br>";
  
          echo "DOB:".$_POST['date'].'<br>';
  
          echo "Email:".$_POST['email']."<br>";
          // echo "Number:".$_POST['snumber']."<br>";
          echo "Language:".'<br>';
              if(!empty($_POST['Language'])){
              foreach($_POST['Language'] as $checked){
                echo $checked."</br>";
              }
            }
          echo "<br>";
          echo "City:".$_POST['City'].'<br>'; 
          echo "Addres".$_POST['address'].'<br>';
        
            $target_dir="img/";
            $target_file=$target_dir.basename($_FILES["pimage"]["name"]);
       
        }

        
        
       

   
?>
</body>
</html>
