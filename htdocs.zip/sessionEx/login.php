<?php
require "config.php";
session_start();
$user=$_POST['username'];
$psw=$_POST['psw'];

    

$sql="Select * from login where username='$user' and password='$psw'";
$res=$conn->query($sql);

    if($res->num_rows>0)
    {
        $row=$res->fetch_object();
        $msg="Login In";
        $_SESSION['msg']=$msg;
        $_SESSION['uid']=$row->id;
        $_SESSION['user']=$row->username;
        if(isset($_POST['rm']))
        {
            $rm=$_POST['rm'];
            setcookie("rm","y",time()+(86400*30));  
        }
        header("Location:index.php");
    }
    else
    {
        $msg="username or password is incorrect";
        $_SESSION['msg']=$msg;
        header("Location:index.php");

    }

?>