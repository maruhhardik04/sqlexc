<?php
    session_start();
    session_unset();
    session_destroy();
    setcookie("rm","",time()-10);
    header("location:index.php");


?>