<?php

require 'config.php';

$name=$_POST['name'];
$item=$_POST['item'];
$mnumber=$_POST['mnumber'];


$sql="insert into customer(Cust_name,Item_purchased,Mob_no) values('$name','$item','$mnumber')";

  if($conn->query($sql) === TRUE)
  {
      echo "Record Inserted.";
      header("Location: index.php");
}
  else
  {
      echo "Error".$conn->error;
  }
$conn->close();

?>