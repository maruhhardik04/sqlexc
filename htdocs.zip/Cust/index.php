<?php require 'config.php'?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer</title>
</head>
<style>
table, th, td {
  border:1px solid black;
}
</style>
<body>
    <form action="insert.php" method="post">
        <span> Name:</span><input type="text" name="name" required><br>
        <span>Item:</span><input type="text" name="item" required><br>
        <span> Mobile_number:</span><input type="text" name="mnumber" id="mnumber" required><br>
        <input type="submit"  value="Insert">
    </form>
     
    <table style="width:100%">
          <tr>
            <th>NO</th>
            <th> Name</th>
            <th> Item</th>
            <th>Mobile number</th>
            <th>Delete</th>
            <th>Update</th>
         </tr>
    <?php
        $sql="select * from customer";
        $result=$conn->query($sql);
        if($result->num_rows>0)
        {
            while($row = $result->fetch_assoc())
            {?>
        <tr>
            <td><?=$row["Cust_no"]?></td>
            <td><?=$row["Cust_name"]?></td>
            <td><?=$row["Item_purchased"]?></td>
            <td><?=$row["Mob_no"]?></td>
            <td><a href="update.php?id=<?=$row["Cust_no"]?>">Update</a></td>
            <td><a href="delete.php?id=<?=$row["Cust_no"]?>">Delete</a></td>
        </tr>
            <?php }
        }
    ?>
    </table>
</body>
</html>