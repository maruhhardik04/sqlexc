<?php 

    require 'config.php';

    $uid=$_GET['id'];
    $sql="Delete from customer where Cust_no=$uid";
    $result=$conn->query($sql);
    if($result)
    {
        header("Location:index.php");
    }
    else
    {
        echo "";
    }

?>