<?php
    require_once "config.php";
    $uid=$_GET['id'];
    $sql="select * from customer where Cust_no=$uid";
    $result=$conn->query($sql);
    $row=$result->fetch_assoc();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit</title>
</head>
<body>        

  <form  method="post">
        <span> Name:</span><input type="text" name="name" value="<?=$row['Cust_name']?>" required><br>
        <span>Item:</span><input type="text" name="item" value="<?=$row['Item_purchased']?>" required><br>
        <span> Mobile_number:</span><input type="text" name="mnumber" value="<?=$row['Mob_no']?>" id="mnumber" required><br>
        <input type="submit" name="Update"  value="Update">
    </form>
     
    <?php

if(isset($_POST['Update'])) 
{
    
    $name=$_POST['name'];
    $item=$_POST['item'];
    $mnumber=$_POST['mnumber'];

$sql="UPDATE customer set Cust_name='$name',Item_purchased='$item',Mob_no=$mnumber where Cust_no=$uid";
$res=$conn->query($sql);
if($res>=0)
{    
    header("Location:index.php");
}
else
{
    echo $conn->error;
}


}


?>
</body>
</html>    

