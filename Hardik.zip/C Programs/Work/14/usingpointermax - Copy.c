#include<stdio.h>
#include<conio.h>

int max(int arr[],int size)
{
   
    int i;
     int *max,*maxp;
     max=arr;
     maxp=arr;
   

     for(i=0;i<size;i++)
     {
         if(*maxp>=*max)
         {
             *max=*maxp;
         }
         maxp++;
     }
    return *max;
}

int min(int arr[],int size)
{
    int i;
    int *min,*minp;
    min=arr;
    minp=arr;

    for(i=0;i<size;i++)
    {
        if(*minp<=*min)
        {
            *min=*minp;
        }

        minp++;
    }
    return *min;
}


int main()
{

  int arr[]={1,2,3,2,4,5,6,3,1,7,9,7,11,0};
  int size=sizeof(arr)/sizeof(arr[0]);
  printf("Max:%d",max(arr,size));
  printf("\nMin:%d",min(arr,size));
  getch();
  return 0;
    
  
}