#include<stdio.h>

int main()
{
    int n,fact=1;
    printf("Enter Number:");
    scanf("%d",&n);

    while(n>=1)
    {
        fact*=n;
        n--;
    }
    printf("Fact is %d",n,fact);
}