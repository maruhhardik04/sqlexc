#include  <stdio.h>

int fact(int n){
  if(n>=1)
    return n*fact(n-1);
  else 
    return 1;  
    
}


int main()
{
    int n,i;
    double sum=0.0,factt=0.0;
    printf("Enter Number:");
    scanf("%d",&n);
  //  printf("Factorial of %d: %d",n,fact(n));
    
    for (i = 0; i < n; i++)
    {
    	factt=(double)fact(i);
        printf("\n%d / %.2lf = %lf",1,factt,(1/factt));
        sum=sum + (double)(1/factt);
    	
    }
    printf("\nSum:%lf\n",sum);    
  
  
   return 0;
}
