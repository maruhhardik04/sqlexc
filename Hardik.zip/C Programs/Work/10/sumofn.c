#include<stdio.h>

int sumofn(int s,int e)
{   int sum=0;
    while(s<=e)
    {
        sum+=s;
        s++;
    }
 return sum;
}

int sumofnum(int s,int  e)
{
    if(s==e)
        return e;
    else
        return e+sumofnum(s,e-1);    
    
}

int main()
{
    int s,e;
    printf("Enter Start and End Number:");
    scanf("%d %d",&s,&e);
    printf("%d",sumofnum(s,e));
}