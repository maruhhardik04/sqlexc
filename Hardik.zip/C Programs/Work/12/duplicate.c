#include <stdio.h>



int removeduplicate(int arr[],int size)
{
  int flag=0;
   for(int i=0;i<size;i++)
   {
     for(int j=i+1;j<size;j++){
  
         if(arr[i]==arr[j] && arr[i]!=0){
         arr[j]=0;
         flag++;
       }
     }
   }
    for(int i=0,j=0;i<size,j<size-flag;i++){
      if(arr[i]!=0){
       arr[j]=arr[i];
       j++;
    }}
    return size-flag;
}

int main()
{
  
  
  int arr[]={9,1,2,3,8,2,4,5,6,3,1,7,9,7};
  int size=sizeof(arr)/sizeof(arr[0]);
  
  size=removeduplicate(arr,size);
  
   for(int i=0;i<size;i++){
     printf("%d",arr[i]);
   }
  
  return 0;
}