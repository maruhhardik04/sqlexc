#include<stdio.h>
#include<conio.h>
#define minval 0.001

double sqroot(int n)
{

    double start=1,end=n;
    double mid;
    double ans;

    while (start<=mid)
    {
        mid=(start+end)/2;

        if(mid*mid==n)
        {
            return mid;
        }

        if(mid*mid<n)
        {
            start=mid+.0000001;
            ans=mid;
        }
        else
        {
            end=mid-.0000001;
        }
    }
    
    return ans;

}

// double sq2(double n)
// {
//     double low=0.0,high=n,mid=0.0;


//     while (high-low > minval)
//     {
//             mid=low+(high-low)/2;
//             if(mid*mid>minval)
//             {
//                 high=mid;
//             }
//             else
//             {
//                 low=mid;
//             }
//     }
    
//     return mid;
// }

int main()
{

    int n;
    printf("Enter a Number:");
    scanf("%d",&n);

    printf("Sqrt of %d is %.2lf",n,sq2(n));

    getch();
    return 0;
}