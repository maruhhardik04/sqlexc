#include<stdio.h>

void swap(int *x,int *y)
{   
    *x=*x+*y;
    *y=*x-*y;
    *x=*x-*y;
      
}

void Display(int a,int b)
{
    int *x=&a,*y=&b;
    printf("\n\n A:%d \n B:%d",*x,*y);
}

int main()
{
    int a=1,b=2;
    
    Display(a,b);
    swap(&a,&b);
    Display(a,b);

}