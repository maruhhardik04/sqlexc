#include<stdio.h>

int main()
{
    char *string="Hello world";
    int count=0;
    while(string[count]!='\0')
    {
        count++;
    }
    printf("Count of(%s)is:%d",string,count);

}