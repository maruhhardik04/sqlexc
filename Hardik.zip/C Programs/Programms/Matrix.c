#include<stdio.h>
#include<conio.h>
#include<stdlib.h>

typedef struct 
{
    int **matrix;
    int row,col;

}Matrix;

int *Hello()
{
    int *p;
    p=(int*)malloc(5*sizeof(int));
    return p;
}


void main()
{
    int *m=Hello();
    for (int i = 0; i < 5; i++)
    {
        printf("Enter value of:[%d]",i);
        scanf("%d",&m[i]);
    }

    
    getch();
}