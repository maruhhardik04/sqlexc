#include<stdio.h>
#include<conio.h>
#include<math.h>


int main()
{

    int i,n,fact=1,sign=-1;
    float sum,x;

    printf("Enter Value of N:");
    scanf("%d",&n);
    printf("Angle is degree:");
    scanf("%f",&x);
    x=x*3.14/180;
    printf("Angle in Raian :%f",x);
    sum=x;
    for (i = 3; i <= n; i+=2)
    {
        fact=fact * i * (i-1);
        sum=sum+sign*pow(x,i)/fact;
        sign=sign*-1;
    }
    printf("\n\nSum  :%.4f",sum);
    printf("\n\n %d:%d",x,sin(45));
        return 0;
}