#include<stdio.h>
#include<conio.h>
#include<math.h>

void coordinate(double r,double d)
{
    printf("X:%.4lf \n",(double)(r*(cos(d*3.14/180))));
    printf("Y:%.4lf",(double)(r*(sin(d*3.14/180))));
}



int main()
{
    double r,d;
    printf("Enter r:");
    scanf("%lf",&r);
    printf("Enter Degree:");
    scanf("%lf",&d);
    coordinate(r,d);
    getch();
	return 0;
}
