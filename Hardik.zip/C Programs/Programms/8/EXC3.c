#include<stdio.h>
#include<conio.h>
#include<math.h>

double height(int L,int D)
{
    return L * sin(D*3.14/180);
}



int main()
{
    int l,d;
    printf("Enter L:");
    scanf("%d",&l);
    printf("Enter Degree:");
    scanf("%d",&d);
    printf("Height :%lf",height(l,d));
    getch();
	return 0;
}
