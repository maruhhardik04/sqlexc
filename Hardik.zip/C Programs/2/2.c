#include <stdio.h>

int main(int argc, char const *argv[])
{
    int n1=10,n2=220;
    int max=n1;

    (max<n2) && (max=n2);
    printf("%d",max);

    return 0;
}

