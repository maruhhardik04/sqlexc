#include<stdio.h>
#include <stdlib.h>
#include<stdbool.h>


int a,b;
int main(int argc, char const *argv[])
{
  
    char yes='y';
    
    while(yes == 'y' || yes=='Y')
    {
              int ch;
            printf("\n1.Addition");
            printf("\n2.Subtraction");
            printf("\n3.Multiplication");
            printf("\n4.Division");
            printf("\n6.Remainder");
            printf("\nChoose  Operation:");
            scanf("%d",&ch);
            

                switch (ch)
                {
                case 1:
                
                    Addition();
                    break;
                case 2:
                    Subtraction();
                    break;
                case 3:
                    Multiplication();
                    break;
                case 4:
                    Division();
                    break; 
                case 5:
                    Remainder();
                    break;           
            
                default:
                    exit(0);
                    break;
                }
                 printf("Do you Want to Perform More Operations [y/n]:");
                    scanf(" %c", &yes);
              
    }
     
    return 0;
}

void Input()
{
    
     printf("Enter Number 1:");
    scanf("%d",&a);

    
    printf("Enter Number 2:");
    scanf("%d",&b);
}

void Addition()
{   Input();
    printf("\nAnswer is:%d\n",a+b);
}
void Subtraction()
{
     Input();
    printf("\nAnswer is:%d\n",a-b);
}
void Multiplication()
{
     Input();
    printf("\nAnswer is:%d\n",a*b);
}

void Division()
{
     Input();
    printf("\nAnswer is:%d\n",a/b);
}

void Remainder()
{
     Input();
    printf("\nAnswer is:%d\n",a%b);
}
