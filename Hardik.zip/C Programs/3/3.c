#include<stdio.h>
#include <stdlib.h>
#include<stdbool.h>

int main(int argc, char const *argv[])
{

    int year = 0;
    while (true)
    {
    printf("Enter Years:");
    scanf("%d",&year);
    
    int ch;

    printf("\n1.Convert Years Into Month");
    printf("\n2.Convert Years Into Days");
    printf("\n3.Convert Years Into Hours");
    printf("\n4.Convert Years Into Minutes");
    printf("\n0.Exit\n");
    scanf("%d",&ch);


    switch (ch)
    {
    case 1:
        printf("\nIn %d years there are %d Monts\n",year,(year*12));
        break;
    case 2:
        printf("\nIn %d years there are %d Days\n",year,(year*365));
        break;
    case 3:
        printf("\nIn %d years there are %d Hours\n",year,(year*365)*24);
        break;
    case 4:
        printf("\nIn %d years there are %d Minutes\n",year,((year*365)*24)*60);
        break;    
    default:
        exit(0);
        break;
    }
        
}
    

    
    return 0;
}
