#include<stdio.h>
#include<stdbool.h>

int main(int argc, char const *argv[])
{
    int marks[5],total = 0;
    float per;    
    bool fail = false;

    for (int i = 0; i < 5; i++)
    {
        printf("Enter Marks of Subject%d:",i+1);
        scanf("%d",&marks[i]);
        if(marks[i]<50)
            fail = true;
        

        total += marks[i];

    }
    
    per = (total * 100)/500;


    if(fail)
    {
        printf("Fail");
    }
    else
    {
        if(per >= 70)
        {
            printf("Distinction with %.2f",per);
        }
        else if(per>=60)
        {
            printf("First Class with %.2f",per);
        }
        else if(per>=50)
        {
            printf("Second Class with %.2f",per);
        }
    }
    


    return 0;
}
