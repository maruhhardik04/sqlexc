#include<stdio.h>
#include<conio.h>

int main()
{

    int i,n,count=0,sum=0;
    printf("Entet number:");
    scanf("%d",&n);
    
    for(i=1;count<n;i=i+2)
    {
        if(count%2==0)
        {	
            sum+=i;
            //printf("%d",i);
			count++;
        }
        else
        {
        	   
            sum-=i;
            //printf("-%d+",i);
            count++;
        }
    }

   printf("\n%d",sum);
    getch();
    return 0;
}
