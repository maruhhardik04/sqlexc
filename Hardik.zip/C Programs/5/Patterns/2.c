#include<stdio.h>

int main() {
      char abc='A';
     for(int i=1;i<=5;i++)
     {
        for(int j=1;j<=i;j++)
        {
         
          printf("%c",abc);
            
        } 
        printf("\n"); 
        abc++;  
     }
            return 0; 
}