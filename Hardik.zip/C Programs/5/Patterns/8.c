#include<stdio.h>
int Fac(int n)
{
    if(n>=1)
    {
        return n * Fac(n-1);
    }
    else
    {
        return 1;
    }
    
}

int pas(int n,int k)
{
     int res=1;
     if(n==k || k==0)
         return res;

    for (int i = 0; i < k; i++)
    {
       res = Fac(n)/ (Fac(k)  * Fac(n-k));
       return res;
    }
    

}


int main(int argc, char const *argv[])
{
   
    for (int i = 0; i <= 5; i++)
    {
        for(int j=5;j>=i;j--)
        {
         
          printf(" ");
          
        }
        for (int  j = 0; j<=i; j++)
        {
            printf("%d ",pas(i,j));
        }
        printf("\n");
    }
    
    return 0;
}


