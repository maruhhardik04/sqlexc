#include<stdio.h>

int main() {

      int n=0,sum=0,count=0;
     
     float avg;
    
    for(;;)
    {
        printf("Entet number:");
        scanf("%d",&n);
    
       if(n==999)
       {
         break; 
       }  
       sum += n;
       count++;
    }
    avg = (float)sum/count;
    printf("Average of all number is %.2f",avg);
      return 0;
}