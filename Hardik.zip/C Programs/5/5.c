#include<stdio.h>

int main() {
    
    int num = 1234;
    int temp;

    while(num != 0)
    {
      temp = num % 10;
      printf("%d",temp);
      num/=10;
    }
    
      return 0;
}