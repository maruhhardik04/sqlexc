#include<stdio.h>
int main(int argc, char const *argv[])
{
    int old[10]={1,2,3,4,6,6,7,8,9,10};
    int new[10];
    int k=0;

    for(int i=0;i<10;i++)
    {
        for(int j=i+1;j<10;j++)
        {
            if(old[i]==old[j])
            {
                new[k]=old[i];
                printf("%d",new[k]);
                k++;
                old[j]=0;
            }
        }

        
        
    }
    return 0;
}
