#include<stdio.h>
int main(int argc, char const *argv[])
{
    int A[2][2]={{10,20},{4,5}};
    int B[2][2]={{2,33},{20,5}};
    int Sum[2][2];
    for (int i = 0; i < 2; i++)
    {
       for (int j = 0; j < 2; j++)
       {
           Sum[i][j]=A[i][j]+B[i][j];
           printf(" %d ",Sum[i][j]);
           if(j==1)
                printf("\n");
       }
       
    }
    


    return 0;
}
