#include<stdio.h>
int Fac(int n)
{
    if(n>=1)
    {
        return n * Fac(n-1);
    }
    else
    {
        return 1;
    }
    
}


int main(int argc, char const *argv[])
{
    
    int num;
    printf("Enter Number:");
    scanf("%d",&num);

    if((Fac(num-1)+1)%num==0)
    {
        printf("Prime");
    }
    else
    {
        printf("Not Prime");
    }


    return 0;
}
