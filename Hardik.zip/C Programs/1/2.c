#include<stdio.h>

int main(int argc, char const *argv[])
{
    int a,b;
    printf("Enter Number 1:");
    scanf("%d",&a);

    
    printf("Enter Number 2:");
    scanf("%d",&b);
    printf("Addition Of Two Number:%d",a+b);
    printf("\nSubtraction Of Two Number:%d",a-b);
    printf("\nMultiplication Of Two Number:%d",a*b);
    printf("\nDivision Of Two Number:%d",b/a);
    return 0;
}
