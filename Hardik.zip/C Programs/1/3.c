#include <stdio.h>

int main(int argc, char const *argv[])
{
    int temp=0;
    printf("Enter A Temp. IN Fahrenhit:");
    scanf("%d",&temp);

    float c = (temp-32)/1.8;

    printf("Temp. In Celsius:%.2f",c);  

    return 0;
}
