#include<stdio.h>

int main(int argc, char const *argv[])
{
    int marks[]={10,20,30,40,50};
    int total = 0;
    float avg =0;
    int size = sizeof(marks)/sizeof(int);
    for (int i = 0; i < size; i++)
    {
        total += marks[i];
    }
    printf("Total:%d",total);
    avg = total/(sizeof(marks)/sizeof(int));
    printf("\nAverage:%.2f",avg);

    return 0;
}
