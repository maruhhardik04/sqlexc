import java.util.Scanner;

public class EX31 {
    public static void main(String[] args) {
        
        Scanner sc=new Scanner(System.in);
        try{
           System.out.println("Enter Two Numbers:");
           int a=sc.nextInt();
           int b=sc.nextInt(); 
            System.out.println("Division is:"+(a/b));
        }catch(ArithmeticException e)
        {
            System.out.println(e);
        }
        

    }
}
