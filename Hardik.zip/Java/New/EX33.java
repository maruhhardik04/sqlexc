import java.util.Scanner;

public class EX33 {
 
    private int balance;
    Scanner sc=new Scanner(System.in);
    

    public static void main(String[] args) {
     
            EX33 obj = new EX33();
            obj.setBalance(1000);
            System.out.println("Balance is:"+obj.getBalance());
            obj.withdraw(400);
            System.out.println("Balance is:"+obj.getBalance());
            obj.withdraw(300);
            System.out.println("Balance is:"+obj.getBalance());
            obj.withdraw(500);
            System.out.println("Balance is:"+obj.getBalance());
        }


    public void withdraw(int w)
    {
        try {   
                if(this.balance<w)
                    throw new Exception("Not Sufficient Fund");
                this.balance=this.balance-w;           
        } catch(Exception e) {
            System.out.println(e);
        }
    }

    public int getBalance() {
        return balance;
    }


    public void setBalance(int balance) {
        this.balance = balance;
    }

}
