import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.function.Predicate;


public class EX43 {
    
    public static void main(String[] args) {
        
     
    //    List<String> cs = Arrays.asList("madam", "test", "tacocat", "hello");
    // System.out.println(count(cs, EX43::checkPalindrome));
        
    //     LinkedList<Integer> integers=new LinkedList<Integer>();
    //     integers.add(121);
    //     integers.add(231);
    //     integers.add(3);
    //     integers.add(4);
    //     integers.add(5);
    //     integers.add(6);
    
    //     System.out.println(count(integers, EX43::checkPrimeNumber));
   
    @Test
    public void testCountingOddNumbers() {
        System.out.println("testCountingOddNumbers");
        List<Integer> ci = Arrays.asList(1, 2, 3, 4, 5, 6);
        long expected = 3l;
        long actual = count(ci, EX43::checkOddNumber);
        Assert.assertEquals(expected, actual);
    }    
    }
    

    public static <T> long count(Collection<T> collection,Predicate<T> predicate)
    {
        return collection.stream().filter(predicate).count();
    } 


    public static boolean checkEvenNumber(final int num) {
        return num % 2 == 0;
    }

    public static boolean checkOddNumber(final int num) {
        return num % 2 != 0;
    }

    public static boolean checkPrimeNumber(final int num) {
        if (num == 0 || num == 1) {
            return false;
        }

        for (int i = 2; i * i <= num; i++) {
            if (num % i == 0) {
                return false;
            }
        }
        return true;
    }

    public static boolean checkPalindrome(final String string)
    {    
        String tem="";
        char s[]=string.toCharArray();
        for (int i = s.length-1; i >= 0; i--) {
            tem+=s[i];
        }
      
             return string.equals(tem);
    }

}
