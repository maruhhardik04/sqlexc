package ColEx;

import java.util.*;

public class Student {
   
    private String Name;
    private  int rollNo;
    private int age;
    private int marks[];
    
    public Student(int rollNo,String Name,int age,int[] marks) {
        this.Name=Name;
        this.rollNo=rollNo;
        this.age=age;
        this.marks=marks;
    }





    public int[] getMarks() {
        return marks;
    }

    public int getRollNo() {
        return rollNo;
    }

    public String getName() {
        return Name;
    }

    public int getAge()
    {
        return age;
    }

    public int total_Marks()
    {   
        int total=0;
        for (int i : this.marks) {
            total+=i;
        }
        return total;
    }


    public static void main(String[] args) {


    
        List<Student> s1 = new LinkedList<Student>();
        s1.add(new Student(1, "Hardik", 23,new int[]{95,95,10,25,14}));
        s1.add(new Student(2, "Yash", 22,new int[]{95,90,20,2,40}));
        s1.add(new Student(3, "Harshit", 21,new int[]{90,95,45,75,64}));
    
        

       
        System.out.println("Sorting by age");  

        Collections.sort(s1,new AgeComp());
         for (Student s: s1) {
          //  if(s.getName().equals(args[0])){
             
            System.out.println();
                System.out.println("Roll NO:"+s.getRollNo());
                System.out.println("Name:"+s.getName());
                System.out.println("Age:"+s.getAge());
                System.out.println("Marks:"+Arrays.toString(s.getMarks()));
                System.out.println("Total Of Marks:"+s.total_Marks());
             
                //}
            
         }




         System.out.println();
         System.out.println("Sorting by Name");  

        Collections.sort(s1,new NameComp());
         for (Student s: s1) {
         
            System.out.println();
                System.out.println("Roll NO:"+s.getRollNo());
                System.out.println("Name:"+s.getName());
                System.out.println("Age:"+s.getAge());
                System.out.println("Marks:"+Arrays.toString(s.getMarks()));
                System.out.println("Total Of Marks:"+s.total_Marks());
            
         }



    }





    // @Override
    // public int compareTo(Student o) {
    //     if(rollNo==o.rollNo) return 0;
    //     if (rollNo<o.rollNo) return 1;
    //     return -1;
    // }




}

class AgeComp implements Comparator<Student>{

    @Override
    public int compare(Student o1, Student o2) {
        if(o1.getAge()==o2.getAge()) return 0;
        if (o1.getAge()<o2.getAge()) return 1;
        return -1;
    }
   
}

class NameComp implements Comparator<Student>{

    @Override
    public int compare(Student o1, Student o2) {
       return o1.getName().compareTo(o2.getName());
    }
   
}


