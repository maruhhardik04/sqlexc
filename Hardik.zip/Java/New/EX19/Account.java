package EX19;

public abstract class Account {


    int accountNo,balance;
    
  
    protected abstract void checkBalance();


    public void setAccountNo(int accountNo) {
        this.accountNo = accountNo;
    }

    public int getAccountNo() {
        return accountNo;
    }

        public void setBalance(int balance) {
    this.balance = balance;
        }

    public int getBalance() {
        return balance;
    }

  
}
    

