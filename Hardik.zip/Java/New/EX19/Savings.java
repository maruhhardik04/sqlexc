package EX19;

public class Savings extends Account{
    
    int interestRate;

    public Savings(int accountNo,int balance,int interestRate){

    }

    @Override
    protected void checkBalance() {
        // TODO Auto-generated method stub
        
    }



}
