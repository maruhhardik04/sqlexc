public class EX32 {

    public static void main(String[] args) {
        
        try{
            System.out.println(Divied(10, 2));  
            System.out.println(Divied(10, 0));  
        }
        catch(ArithmeticException e)
        {
            System.out.println(e);
        }
        finally
        {
            System.out.println("Print");
        }



    }


    public static Double Divied(int a,int b)throws ArithmeticException{
        
        if(b==0)
        {
            throw new ArithmeticException("/ By zero");
        }

        return (double) (a/(double)b);
    }
}
