

public interface File {

}
