import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java
.nio.file.Path;
import java.nio.file.Paths;
public class countline {
    

    public static void main(String[] args) throws FileNotFoundException {
        int count=0;
        File file =new File("Name.txt");
        Scanner scanner=new Scanner(file);
      
        // try {
        //         long line;
        //         Path path=Paths.get("Name.txt");
        //         line = Files.lines(path).count();
        //         System.out.println(line);
        //     } catch (IOException e) {
             
        //         e.printStackTrace();
        //     }
      
        while (scanner.hasNextLine()) {
            scanner.nextLine();
            count++;
        }
        System.out.println(file.getAbsolutePath());
        System.out.println("Total Number of Lines: " + count);
        scanner.close();

    }
}
