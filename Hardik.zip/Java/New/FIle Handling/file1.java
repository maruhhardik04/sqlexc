import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;



/**
 * file1
 */
public class file1 {

    public static void main(String[] args) throws IOException {
        

        File file =new File("Name.txt");
       
        if (!file.exists()) 
        {
            file.createNewFile();
            System.out.println("File Created."); 
        }

       
        
        FileWriter fileWriter=new FileWriter(file);
        fileWriter.write("Hello");
        System.out.println("Successfully wrote to the file.");
        fileWriter.close();
            
            FileReader fileReader=new FileReader(file);
            int i;
            while ((i=fileReader.read())!=-1) {
                System.out.print((char)i);
            }
            fileReader.close();

        System.out.println();

        FileWriter fileWriter2=new FileWriter(file,true);
        fileWriter2.append(" World");
        System.out.println("Successfully append into  the file.");
        fileWriter2.close();

                    FileReader fileReader1=new FileReader(file);
                    int j;
                    while ((j=fileReader1.read())!=-1) {
                        System.out.print((char)j);
                    }
                    fileReader1.close();
    }

   
    
}