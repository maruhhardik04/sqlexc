

public @interface Test {

}
