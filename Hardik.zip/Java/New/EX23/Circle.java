package EX23;

import java.io.PushbackReader;

public class Circle extends Shape{

    private final double PI=3.14; 
    private double r;


    public Circle(double r) {
        this.r=r;
    }


    @Override
    public void area() {
    
        System.out.println("Area Of Triangle is:"+(PI*r*r));
        
    }

    
}
