import java.util.Arrays;

public class EX44 {
    
        public static void main(String[] args) {

            Integer arr[] = {10,20,30,40,50}; 
            String  arr1[]={"Hardik","Yash","Harshit"}; 
            System.out.println(Arrays.toString(arr));
            exchange(arr,1,2);
            System.out.println(Arrays.toString(arr));
            System.out.println(Arrays.toString(arr1));
            exchange(arr1,1,2);
            System.out.println(Arrays.toString(arr1));
        }

        public static <T> void exchange(T[] arr,int currentPos,int toPos){

                T temp=arr[currentPos];
                arr[currentPos]=arr[toPos];
                arr[toPos]=temp;

        } 




}
