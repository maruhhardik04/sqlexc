class MyGEN<T,S>{

    T t;
    S s;
   
    public MyGEN(T t,S s) {
        this.setT(t);
        this.setS(s);   
    }

    public void setS(S s) {
        this.s = s;
    }

    public void setT(T t) {
        this.t = t;
    }

    public T getT() {
        return t;
    }
    public S getS() {
        return s;
    }

    
}

public class EX1{
    public static void main(String[] args) {
        MyGEN<Integer,String> gen = new MyGEN<Integer,String>(10,"Hello");

        System.out.println(gen.getT() + "\n" + gen.getS());
 
    }
}
