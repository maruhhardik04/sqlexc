class MyGEN<T>{

    T t1;
    public void setValue(T t1)
    {
        this.t1=t1;
    }

    public T getValue(){
        return t1;
    }
    
}

public class EX {
    public static void main(String[] args) {
        MyGEN<Integer> gen = new MyGEN<Integer>();
        gen.setValue(10);
        System.out.println(gen.getValue());

        MyGEN<Float> gen2= new MyGEN<>();
        gen2.setValue(10.5f);
        System.out.println(gen2.getValue());


    }
}
