public  class EX15
{

    static{
        System.out.println("Static Block");
    }

    public static void main(String[] args) {
        System.out.println("main Method");
    }
}