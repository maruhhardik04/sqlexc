public class EX21{

    public static void main(String[] args) {
        final int a=10;
        System.out.println(a);
        //a=20;
    }

}

    
