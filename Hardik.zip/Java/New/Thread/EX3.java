class NewThread extends Thread{


    private int _sleep;
    private String _Name;


    public NewThread(String Name,int sleep) {
        this.set_sleep(sleep);
        this.set_Name(Name);
    }

    public void run()
    {
        try {
            for (int i = 0; i < 5; i++) {
                Thread.sleep(this.get_sleep());
                System.out.println(this.get_Name()+ ":" + i);
            }
        } catch (InterruptedException e) {
          System.out.println(e.getMessage());
        }
    }


    public void set_Name(String Name)
    {
            this._Name=Name;
    }

    
    public void set_sleep(int _sleep) {
        this._sleep = _sleep;
    }
    
    public int get_sleep() {
        return _sleep;
    }
    
    public String get_Name()
    {
        return _Name;
    }
    
    
    
    
}



public class EX3 {
    

    public static void main(String[] args) {
        

        NewThread n1=new NewThread("Thread1", 2000);
        NewThread n2=new NewThread("Thread2", 4000);
        n1.start();
        n2.start();


    }


}
