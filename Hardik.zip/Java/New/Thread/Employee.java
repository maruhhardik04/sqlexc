import java.util.Scanner;
import java.util.jar.Attributes.Name;

public class Employee {

    private String Name;

    Employee()
    {
        this.Name="Unknow";
    }

    Employee(String Name)
    {
        this.Name=Name;
    }

    public String getName() {
        return Name;
    }

    public static void main(String[] args) {
    
    String Name;
    Scanner scanner =new Scanner(System.in);
    System.out.print("Enter A Name:");
    Name=scanner.nextLine();
    
    System.out.println(Name.trim().equals(""));
    
    if(Name.trim().equals(""))
    {
        Employee employee =new Employee();
        System.out.println("Name:"+employee.getName());
    
    }        
    else{
        Employee employee=new Employee(Name);
        System.out.println("Name:"+employee.getName());

    }
      
    
    



    }
}
