public class EX2 implements Runnable{


    @Override
    public void run() {
        System.out.println("Thread is Running....");
        
    }
    

    public static void main(String[] args) {
        
        Thread thread=new Thread(new EX2());
        thread.start();

    }
}
