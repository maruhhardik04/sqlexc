class Avg {

    
    public static void main(String[] args) {
        
    int total=0;
       
    for (String string : args) {
        
        
           
            try {
                total+=Integer.parseInt(string);
            } catch (Exception e) {
                    System.out.println("Not A Numebr");
                    return;
                   
            }
        }


        System.out.println("Average is :"+(total/args.length));
    }

}
