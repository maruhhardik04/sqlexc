import java.util.Scanner;

/**
 * Series
 */
class Ser{


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter Number:");
        int n =sc.nextInt();
        Display(serir(n));
        sc.close();
    }
    
    public static int[] serir(int n)
    {
        int[] ans=new int[n];
        int res=1;
        for (int j = 0; j < n; j++) {
            ans[j]=res;
            res*=2;
        }
        
        return ans; 
    }

    public static void Display(int[] ans)
    {

        //System.out.println(Arrays.toString(ans));

            for(int i:ans){

                System.out.print(i+" ");
            }
    }
    
}