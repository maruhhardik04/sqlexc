class freq {
    
    public static void main(String[] args) {
        
        
        char[] string=args[0].toCharArray();
        

        
        for(int i=0;i<string.length;i++)
        {
            int count=1;
            for(int j=i+1;j<string.length;j++)
            if(string[i]==string[j])
            {
                count++;    
                string[j]='0';
            
            }
            if(string[i]!='0'){
                System.out.println(string[i]+"-"+count);
            }
        }

    }
}
