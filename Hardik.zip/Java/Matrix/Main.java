class Main extends Matrix{  
  public static void main(String args[]){  
         Matrix m=new Matrix();
         m.setMatrix();
         m.showMatrix();
        //  m.sumOfRow(); 
        //  m.sumofColumn();  
        Matrix m1=new Matrix();
        m1.setMatrix();
        m1.showMatrix();
        System.out.println("Sum of Two Matrix:");
        m1.sumOfMatrix(m);
  }  
}  
