import java.util.*;
public class Matrix{
  private int[][] matrix; 
   Scanner sc =new Scanner(System.in);
   
   protected void setMatrix(){
     matrix=new int[3][2];
     
     for(int i=0;i<matrix.length;i++){
       for(int j=0;j<matrix[i].length;j++){
           System.out.print("Enter the value of matrix["+(i+1)+"]["+(j+1)+"]:" );
           matrix[i][j]=sc.nextInt();
          }
     }
   }
   
   protected void showMatrix(){
     for (int i = 0; i < matrix.length; i++) {
         for (int j = 0; j < matrix[i].length; j++) { //quals to the column in each row.
            System.out.print(matrix[i][j] + " ");
         }
         System.out.println(); 
      }
     
   }
   
   protected void sumOfRow(){
    
     for (int i = 0; i <matrix.length; i++) {
         int sum=0;
         for (int j = 0; j <matrix[i].length; j++) { //quals to the column in each row.
             sum+=matrix[i][j]; 
         }
         System.out.println("Sum of "+(i+1)+" row is:"+sum); 
      }
   }

   protected void sumofColumn()
   {
  
    int row=matrix.length;
    int col=matrix[0].length;

    for (int i = 0;i<col; i++) {
      int sum=0;
      for (int j = 0; j<row;j++) { //quals to the column in each row.
          sum+=matrix[j][i]; 
      }
      System.out.println("Sum of "+(i+1)+" column is:"+sum); 
      sum=0;
   }
   }

   protected void sumOfMatrix(Matrix m1)
   {
          for (int i = 0; i < m1.matrix.length; i++) {
                for (int j = 0; j < m1.matrix[i].length; j++) {
                  System.out.print(" "+(this.matrix[i][j]+m1.matrix[i][j]));
                }
                System.out.println();
          }
   }

  }