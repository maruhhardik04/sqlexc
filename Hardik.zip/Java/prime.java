class prime{

    public static void main(String args[]) {

        
            int count,n1=0;
            int n=6;
        for(int j=2;n1<n;j++)
        {
            count=0;
        for(int i=2;i<j;i++)
        {
            if(j%i==0)
            {
                n1++;
                count++;
                break;
            }
        
        }
        
        if(count==0)
        {
            System.out.println(j);
        }
        // if(n1==n) break;
        
       
        
    }

    }


}