package Area;

class Circle {
    private int radius;
    protected static int count;

    static
    {
        count=0;
    }

    Circle() {
        count++;
    }

    Circle(int radius)
    {
        this();
        this.radius=radius;
    }

    protected void areaOfCircle()
    {
        System.out.println("Area of Circle is:"+(3.14*(radius*radius)));
    }

}
