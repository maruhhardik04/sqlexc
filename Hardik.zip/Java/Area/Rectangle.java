package Area;

/**
 * Rectangle
 */
public class Rectangle {

    private int length,width;
    protected static int count;
  
    // Initializer block starts..
    // {
    //     System.out.println("Constructors invoked !!");
    // }
    
    //static Block

    static
    {
        count = 0;
        System.out.println("Static");
  
    }
        //default Counstructor
     Rectangle() {
        this.length=10;
        this.width=15;
        System.out.println("default constructor");
        count++;
    }
    //parameterized Counstructor
     Rectangle(int length,int width)
    {
        this.length=length;
        this.width=width;
        System.out.println("parameterized constructor");
        count++;
    }
    //copy Counstructor
     Rectangle(Rectangle rectangle)
    {
        this.length=rectangle.length;
        this.width=rectangle.width;
        count++;
        System.out.println("copy constructor");

    }

    protected void Area()
    {
        System.out.println("Area of Rectangle:"+(length*width));
    }
    
    protected void Area(int length,int width)
    {
        System.out.println("Area of Rectangle:"+(length*width));
    }
}