class SwapClass{
    
    int a;
    public SwapClass(int i) {
        this.a=i;
    }

    protected void Swap(SwapClass c1)
    {
        
    System.out.println("Value of 1 Object before Swap :"+this.a);
    System.out.println("Value of 2 Object before Swap :"+c1.a);



        int tem=this.a;
        this.a=c1.a;
        c1.a=tem;

    System.out.println("Value of 1 Object after Swap :"+this.a);
    System.out.println("Value of 2 Object after Swap :"+c1.a);


    }



    public static void main(String[] args) {
        SwapClass c=new  SwapClass(10);
        SwapClass c1=new SwapClass(20);
        c1.Swap(c);
    }


}