package Student;

class Student1{
    private String name,gender;
    private int r_no,marks;
    private static int count=0;


    Student1() {
        this.name="Hardik";
        this.gender="Male";
        this.r_no=1;
        this.marks=50; 
        count++;

    }

    Student1(int r_no,int marks,String name,String gender)
    {
        this.r_no=r_no;
        this.marks=marks;
        this.name=name;
        this.gender=gender;
        count++;
    }

    protected void display() {
        System.out.println("Roll Number:"+r_no);
        System.out.println("Name:"+name);
        System.out.println("Gender:"+gender);
            System.out.println("Marks:"+marks);
    }

    public static void objectCount()
    {
        System.out.println("Total object Created:" + count);
    }
}