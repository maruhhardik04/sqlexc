#include<stdio.h>

long int fact(int n){
    
    if(n>=1) return n*fact(n-1);
    return 1;  
    
}

int fact1(int n){
    
    int fact=1;
    while(n>=1)
    {
        fact *= n;
        n--;
    }
          
    return fact;
}

int main()
{
    int num;
    printf("Enter a number:");
    scanf("%d",&num);
    printf("Factorial: %ld",fact(num));
}
