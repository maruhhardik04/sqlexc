#include<stdio.h>
#include<conio.h>
#include <stdlib.h>

typedef struct{
    float **matrix;
    int row,col;
}Matrix;


Matrix Create()
{

    Matrix m;
    int i,j;
    printf("Enter the no.of row and columns:");
    scanf("%d %d",&m.row,&m.col);

       m.matrix=(float **)malloc(m.row * sizeof(float*));

     for (i = 0; i < m.row; i++)
     {
	 m.matrix[i]=(float *)malloc(m.col * sizeof(float));
     }

    printf("Enter  Value Of Matrix:\n");
    for (i = 0; i < m.row;i++)
	    for (j = 0; j < m.col; j++)
	    {
	        scanf("%f",&m.matrix[i][j]);
	    }

   return m;
}

void Print(Matrix *m)
{
    int i,j;
	for(i=0;i<m->row;i++)
    {
	for(j=0;j<m->col;j++)
	{
	    printf("%f ",m->matrix[i][j]);
	}
	printf("\n");
    }
}


int Determinants(Matrix *m)
{
         int d=0;
        if(m->row == 2)
        {
         
            d=((m->matrix[0][0]*m->matrix[1][1])-(m->matrix[0][1]*m->matrix[1][0]));
            
        }

        // if(m->row==3)
        // {

        // }
            if(d<=0)
            {
                printf("Inverse of Matrix is Not Possible");
                return 0;
            }
            
            return d;




}


void inverse(Matrix *m)
{
    
    
    det=Determinants(m);
    if(m->row==2)
    {
        m->matrix[0][0] = (m->matrix[1][1]/det);
        m->matrix[1][1] = (m->matrix[0][0])/det;
        m->matrix[0][1] =  (-(m->matrix[0][1]))/det;
        m->matrix[1][0] = (-(m->matrix[1][0]))/det;
    }
    

}





int main()
{
    int Det;
    Matrix A,invA;
    printf("Creating Matrix A:\n");
    A=Create();
    inverse(&A);
    printf("Inverse of A:\n");
    Print(&invA);
    return 0;
}