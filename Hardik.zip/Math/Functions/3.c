#include<stdio.h>
#include<math.h>


int main(){


        float num;
        printf("Enter a number:");
        scanf("%f",&num);

        printf("Floor Value:%f \n Ceil Value:%f \n Round Value:%f",floor(num),ceil(num),round(num));

        return 0;



}