#include<stdio.h>
#include<conio.h>
#include <stdlib.h>
#include<stdbool.h>

typedef struct{
    int **matrix;
    int row,col;
}Matrix;


Matrix Create()
{

    Matrix m;
    int i,j;
    printf("Enter the no.of row and columns:");
    scanf("%d %d",&m.row,&m.col);

       m.matrix=(int **)malloc(m.row * sizeof(int*));

     for (i = 0; i < m.row; i++)
     {
	 m.matrix[i]=(int *)malloc(m.col * sizeof(int));
     }

    printf("Enter  Value Of Matrix:\n");
    for (i = 0; i < m.row;i++)
	    for (j = 0; j < m.col; j++)
	    {
	        scanf("%d",&m.matrix[i][j]);
	    }

   return m;
}

void Print(Matrix *m)
{
    int i,j;
	for(i=0;i<m->row;i++)
    {
	for(j=0;j<m->col;j++)
	{
	    printf("%d ",m->matrix[i][j]);
	}
	printf("\n");
    }
}



Matrix Transpose(Matrix *m)
{
    int i,j,k;
    Matrix mt;
    mt.row=m->col;
    mt.col=m->row;


     mt.matrix=(int**)malloc(mt.row * sizeof(int*));
    
     for (i = 0; i < mt.row; i++)
     {
	     mt.matrix[i]=(int *)malloc(mt.col * sizeof(int));
     }

    for(i=0;i<m->row;++i)
    {
            for (j = 0;j<m->col;++j)
            {
                mt.matrix[j][i]=m->matrix[i][j];
                
            }
            
    }
    return mt;

}

void  Reflexive(Matrix *m)
{
    int i,j,count=0;
    for (i = 0; i < m->row; i++)
    {
        for ( j = 0; j < m->col; j++)
        {
            if(i==j)
            {
                if(m->matrix[i][j]==1)
                {
                    count++;
                }
            }
        }
        
    }

    if(count==m->row)
    {
         printf("Matrix is Reflexive");
    }
    
}



void Symmatric(Matrix *m)
{
    int i,j,count=0;
    Matrix tm;
    tm=Transpose(m);

    for(i=0; i<m->row; i++)
     {
	for(j=0; j<m->col; j++)
	{
	    if(m->matrix[i][j] == tm.matrix[i][j])
	    {
	       count++;
	       if(count==(m->row*m->col))
	       {
		       printf("Matrix is Symmatric");
	       }
	    }
	}
}
}

void Antisymmatric(Matrix *m)
{
    int i,j;
    bool check;
    Matrix tm;
    tm=Transpose(m);

    for(i=0; i<m->row; i++)
     {
	for(j=0; j<m->col; j++)
	{
	    if(m->matrix[i][j] != -(tm.matrix[i][j]))
	    {
            check=false;
	    }
	}
}

    if(!check)
    {
            printf("Matrix is Anti-Symmatric");
    }
    else
    {
        printf("Matrix is not Anti-Symmatric");
    }
}


int main()
{

    Matrix m;
    m=Create();
    Symmatric(&m);
    printf("\n");
    Reflexive(&m);
    printf("\n");
    Antisymmatric(&m);
    return 0;
}