#include<stdio.h>

int GCD(int a,int b)
{
    int rem;
    while(b!=0)
  {
        rem=a%b;
        a=b;
        b=rem;
  }
  return a;
}

int main()
{
    int m,n,lcm;  
        printf("Enter values two find gcd:");
        scanf("%d %d",&m,&n);
  
        if(m==0 && n==0){
                printf("value can not be zero");
                return 0;
         }
  
    printf("GCD IS:%d",GCD(m,n));
    printf("\nLCM IS:%d",((m*n)/GCD(m,n)));
}