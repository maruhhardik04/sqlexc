/* Given two positive integers, m and n, find whether they are relative prime
 numbers or not.*/

#include <stdio.h>

int GCD(int a,int b);


int main()
{

    int m,n;
    printf("Enter values two number:");
    scanf("%d %d",&m,&n);
      
      if(GCD(m,n)!=1)
      {
            printf("Not Relative Prime");
            return 0;
      }
    
    printf("Relative Prime");


    
    return 0;
}




int GCD(int n1,int n2)
{
    int rem;
    while(n2 != 0)
  {
        rem=n1%n2;
        n1=n2;
        n2=rem;
  }
  return n1;
}