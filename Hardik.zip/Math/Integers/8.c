#include <stdio.h>

void Convert(int Dec,int div)
 {   
     //char a;
//     int K,j,binary[20],i=0;
//     while (Dec != 0)
//     {
//         binary[i++]=Dec%div;
//         Dec/=div;
//     }
    
 
//     for (j=i-1;j>=0; j--)
//     {
//         if(div==10)
//         {

//             K=10-binary[j];
//             printf("%d",K);
//         }
//         else
//         {
//             printf("%d",binary[j]);
//         }
//     }
    
         
	int rem=Dec%div;
	if(Dec==0)
		return;
	Convert(Dec/div,div);
	if(rem<10)
		printf("%d",rem);    
	else
		printf("%c",rem-10+'A');   
    

} 


int main()
{

    int num;
    printf("Enter a Number:");
    scanf("%d",&num);
    printf("\nBinary:");
    Convert(num,2);
    printf("\nOctal:");
    Convert(num,8);
    printf("\nHexadecimal:");
    Convert(num,16);

    return 0;
}