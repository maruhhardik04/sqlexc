#include<stdio.h>
#include<stdbool.h>

int main(){
	
	int num,i,j;
	bool isPrime;
	printf("Enter A Number:");
	scanf("%d",&num);

	for (i=2;i<=num;i++)
	{
                 if(num%i==0)
                {

            isPrime=true;
            for (j = 2; j < (i/2); j++)
            {
                    if(i%j==0)
                    {
                        isPrime=false;
                        break;
                    }
            }
            
            if(isPrime)
            {	
                    printf(" %d ",i);
            }
        
                }

	}


	return 0;
}

