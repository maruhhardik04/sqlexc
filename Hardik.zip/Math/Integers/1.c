#include<stdio.h>
#include<math.h>
#include<stdbool.h>

int main(){
	
	int num,i;
	bool isPrime=true;
	printf("Enter A Number:");
	scanf("%d",&num);
	
	if(num<2)
	{
		return 0;
	}

	for (i=2;i<num;i++)
	{
		if(num%i==0)
		{
			isPrime=false;
			break;
		}
	}
	
	if(isPrime)
	{
		printf("Enter Number Is Prime");
	}

	return 0;
}

