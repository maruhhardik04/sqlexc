#include<stdio.h>
#include<conio.h>
#include <stdlib.h>

typedef struct{
    int **matrix;
    int row,col;
}Matrix;


Matrix Create()
{

    Matrix m;
    int i,j;
    printf("Enter the no.of row and columns:");
    scanf("%d %d",&m.row,&m.col);

       m.matrix=(int**)malloc(m.row * sizeof(int*));

     for (i = 0; i < m.row; i++)
     {
	 m.matrix[i]=(int *)malloc(m.col * sizeof(int));
     }

    printf("Enter  Value Of Matrix:\n");
    for (i = 0; i < m.row;i++)
	    for (j = 0; j < m.col; j++)
	    {
	        scanf("%d",&m.matrix[i][j]);
	    }

   return m;
}



void Print(Matrix *m)
{
    int i,j;
	for(i=0;i<m->row;i++)
    {
	for(j=0;j<m->col;j++)
	{
	    printf("%d ",m->matrix[i][j]);
	}
	printf("\n");
    }
}

Matrix MatrixAddition(Matrix *m,Matrix *n)
{
    int i,j;
    
    Matrix sum;
    sum.row=m->row;
    sum.col=m->col;


     sum.matrix=(int**)malloc(sum.row * sizeof(int*));
    
     for (i = 0; i < sum.row; i++)
     {
	     sum.matrix[i]=(int *)malloc(sum.col * sizeof(int));
     } 



    if(m->row==n->row && m->col==n->col)
    {
        for (i = 0; i < m->row; i++)
        {
            for (j = 0; j< m->col; j++)
            {
                sum.matrix[i][j]=(m->matrix[i][j]+n->matrix[i][j]);
                printf(" %d ",(m->matrix[i][j]+n->matrix[i][j]));            
	    }
	    printf("\n");
	}


    }
    else
    {
	printf("\nMatrix Addition is not posible because both matrix are not have same no of rows and column.\n");
    }

    return sum;
}


Matrix MatrixSubtraction(Matrix *m,Matrix *n)
{
    int i,j;

    Matrix sub;
    sub.row=m->row;
    sub.col=m->col;


     sub.matrix=(int**)malloc(sub.row * sizeof(int*));
    
     for (i = 0; i < sub.row; i++)
     {
	     sub.matrix[i]=(int *)malloc(sub.col * sizeof(int));
     } 


    if(m->row==n->row && m->col==n->col)
    {
	for (i = 0; i < m->row; i++)
	{
	    for (j = 0; j< m->col; j++)
	    {
          sub.matrix[i][j]=(m->matrix[i][j]-n->matrix[i][j]);
		printf(" %d ",(m->matrix[i][j]-n->matrix[i][j]));
	    }
	    printf("\n");
	}


    }
    else
    {
	printf("\nMatrix Subtraction is not posible because both matrix are not have same no of rows and column.\n");
    }

    return sub;
}


Matrix Transpose(Matrix *m)
{
    int i,j,k;
    Matrix mt;
    mt.row=m->col;
    mt.col=m->row;


     mt.matrix=(int**)malloc(mt.row * sizeof(int*));
    
     for (i = 0; i < mt.row; i++)
     {
	     mt.matrix[i]=(int *)malloc(mt.col * sizeof(int));
     }

    for(i=0;i<m->row;++i)
    {
            for (j = 0;j<m->col;++j)
            {
                mt.matrix[j][i]=m->matrix[i][j];
                
            }
            
    }
    return mt;

}

int Equal(Matrix *m,Matrix *n)
{
   int i,j;  
    for(i=0;i<m->row;i++)
    {
		for(j=0;j<m->col;j++)
        {
            if(m->matrix[i][j]!=n->matrix[i][j])
			    return 1;
        }
        
	} 
    return 0;
}

int main()
{
	
	Matrix A,B,AT,BT,sumt,subt,AB,ABT,subAB,subABT;
	printf("Creating Matrix A:\n");
	A=Create();
    printf("Transpose of Matrix A:\n");
    AT=Transpose(&A);
    Print(&AT);
	printf("Creating Matrix B:\n");
	B=Create();
    printf("Transpose of Matrix B:\n");
    BT=Transpose(&B);
    Print(&BT);
    printf("\nA+B\n");
    AB=MatrixAddition(&A,&B);
    printf("\n(A+B)T\n");
    ABT=Transpose(&AB);
    Print(&ABT);
    printf("\nA-B\n");
    subAB=MatrixSubtraction(&A,&B);
    printf("\n(A-B)T\n");
    subABT=Transpose(&subAB);
    Print(&subABT);
    printf("\nAT  +  BT\n");
    sumt=MatrixAddition(&AT,&BT);
    printf("\nsubtrction of AT and BT:\n");
    subt=MatrixSubtraction(&AT,&BT);

    printf("\n (AT + BT ) equal (A + B)T\n");
    if(Equal(&sumt,&ABT)==0)
        printf("True");
    else
        printf("False");    


    printf("\nA' - B' equal (A–B)'\n");
     if(Equal(&subt,&subABT)==0)
        printf("True");
     else
        printf("False");  

   getch(); 
   return 0;
}
