#include<stdio.h>
#include<conio.h>
#include <stdlib.h>

typedef struct{
    int **matrix;
    int row,col;
}Matrix;

Matrix Create()
{

    Matrix m;
    int i,j;
    printf("Enter the no.of row and columns:");
    scanf("%d %d",&m.row,&m.col);

       m.matrix=(int**)malloc(m.row * sizeof(int*));
    
     for (i = 0; i < m.row; i++)
     {
         m.matrix[i]=(int *)malloc(m.col * sizeof(int));
     }
    
    printf("Enter  Value Of Matrix:\n");
    for (i = 0; i < m.row;i++)
    {
        for (j = 0; j < m.col; j++)
        {
            scanf("%d",&m.matrix[i][j]);
        }
  }
   return m;
}

void MatrixAddition(Matrix *m,Matrix *n)
{
    int i,j;
    
    if(m->row==n->row && m->col==n->col)
    {
        for (i = 0; i < m->row; i++)
        {
            for (j = 0; j< m->col; j++)
            {
                printf(" %d ",(m->matrix[i][j]+n->matrix[i][j]));            
	    }
	    printf("\n");
	}


    }
    else
    {
	printf("\nMatrix Addition is not posible because both matrix are not have same no of rows and column.\n");
    }


}


void MatrixSubtraction(Matrix *m,Matrix *n)
{
    int i,j;

    if(m->row==n->row && m->col==n->col)
    {
	for (i = 0; i < m->row; i++)
	{
	    for (j = 0; j< m->col; j++)
	    {
		printf(" %d ",(m->matrix[i][j]-n->matrix[i][j]));
	    }
	    printf("\n");
	}


    }
    else
    {
	printf("\nMatrix Subtraction is not posible because both matrix are not have same no of rows and column.\n");
    }


}



int main()
{
    Matrix A,B;
     printf("Creating Matrix A:\n");
    A=Create();
    printf("Creating Matrix B:\n");
    B=Create();
    printf("\nA+B\n");
    MatrixAddition(&A,&B);
    printf("\nA+B\n");
    MatrixSubtraction(&A,&B);
    getch();
	return 0;
}
