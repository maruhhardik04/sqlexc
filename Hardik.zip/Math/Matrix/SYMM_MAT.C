#include<stdio.h>
#include<conio.h>

int main()
{
     int m,n,i,j,k,A[10][10],Transpose[10][10],count=0;
     printf("enter no of rows & cols for A: \n");
     scanf("%d %d",&m,&n);

     printf("enter elements for A: \n");
     for(i=0; i<m; i++)
	for(j=0; j<n; j++)
	       scanf("%d",&A[i][j]);



     for(i=0; i<m; i++)
	for(j=0; j<n; j++)
		  Transpose[j][i]=A[i][j];


     printf("Transpose of A is: \n");
     for(i=0; i<n; i++)
     {
	for(j=0; j<m; j++)
	{
	       printf("%d \t",Transpose[i][j]);

	}
	printf("\n");
     }


     for(i=0; i<m; i++)
     {
	for(j=0; j<n; j++)
	{
	    if(A[i][j]==Transpose[i][j])
	    {
	       count++;
	       if(count==(m*n))
	       {
		       printf("symmatric");
		       getch();
		       return 0;
	       }
	    }
	}
     }
     printf("not symmatric");
     getch();
     return 0;
}
