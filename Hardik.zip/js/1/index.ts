f11:()=>{
    let num1:number
    let num2:number

}