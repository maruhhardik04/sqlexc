DECLARE
    A NUMBER(3);
    B NUMBER(3);
    -- //C NUMBER(3);
BEGIN
    A:=&A;
    B:=&B;
    -- C:=A+b;    
    dbms_output.put_line('Addition:'||(A+B));
END;
/

-- PROCEDURE
CREATE or REPLACE PROCEDURE p1(a number,b number)
is
BEGIN
    dbms_output.put_line('Addition:'||(a+b));
END;



-- Function
CREATE or REPLACE FUNCTION Addition(a number,b number)
RETURN NUMBER
IS
BEGIN
    RETURN (a+b);
END;
/

DECLARE
    a NUMBER(3);
    b NUMBER(3);
BEGIN
    a:=&a;
    b:=&b;
    dbms_output.put_line('Addition of '|| a || ' and '|| b || ' is ' ||Addition(a,b));
END;
/



BEGIN
    dbms_output.put_line('Addition of '|| a || ' and '|| b || ' is ' ||Addition(&a,&b));
END;
/