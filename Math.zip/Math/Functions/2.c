#include<stdio.h>
#include<conio.h>

int fibo(int n)
{
    if(n<2)
        return n;

    return fibo(n-1)+fibo(n-2);
}

    
void fibo1(int n)
{
    int i,a=0,b=1,c=0;
    printf("%d %d ",a,b);
    for(i=0;i<n-2;i++)
    {
        c=a+b;
        a=b;
        b=c;
        printf("%d ",c);
    }
}


int main()
{
    
    int num,i;
    printf("Enter How many squence:");
    scanf("%d",&num);

  //  fibo1(num);
     for (i = 0; i < num; i++)
     {
         printf("%d ",fibo(i));
     }
    getch();
	return 0;
}
