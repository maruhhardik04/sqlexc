#include<stdio.h>
#include<stdbool.h>

int main(){
	
	int num,i,j,count=0;
	bool isPrime;
	printf("Enter A Number:");
	scanf("%d",&num);

	for (i=2;count<num;i++)
	{
		isPrime=true;
        for (j = 2; j < i; j++)
        {
				if(i%j==0)
				{
					isPrime=false;
					break;
				}
        }
		
		if(isPrime)
		{		count++;
				printf(" %d ",i);
		}
	
	}


	return 0;
}

