#include<stdio.h>
#include<conio.h>
void main()
{
	 int *x,n,i;
	clrscr();
	printf("Enter a how many elements you required in set A:-");
	scanf("%d",&n);
	printf("\n enter the elements: ");
	for(i=0;i<n;i++)
	{
		scanf("%d",&x[i]);
		if((x[i]==0) || (x[i]==NULL))
		{
			printf("\n zero is the number of given set");
		}
		else
		{
		}
	}
		printf("\n Element of the given set is = {");
		for(i=0;i<n;i++)
		{
		printf("%d",x[i]);
		if(i!=n-1)
		{
		     printf(",");
		}

	}
	printf("}");
	getch();
}
