#include<stdio.h>
#include<conio.h>
void main()
{
	int *x,n,i;
	printf("Enter a how many elements you required in set A:-");
	scanf("%d",&n);
	printf("\n enter the elements: ");
	for(i=0;i<n;i++)
	{
	 scanf("%d",&x[i]);
	}
	printf("size of given set A is %d \n",n);
	getch();
}