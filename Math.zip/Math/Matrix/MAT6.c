#include<stdio.h>
#include<conio.h>
#include <stdlib.h>

typedef struct{
    int **matrix;
    int row,col;
}Matrix;

Matrix Create()
{

    Matrix m;
    int i,j;
    printf("Enter the no.of row and columns:");
    scanf("%d %d",&m.row,&m.col);

       m.matrix=(int**)malloc(m.row * sizeof(int*));
    
     for (i = 0; i < m.row; i++)
     {
         m.matrix[i]=(int *)malloc(m.col * sizeof(int));
     }
    
    printf("Enter  Value Of Matrix:\n");
    for (i = 0; i < m.row;i++)
    {
        for (j = 0; j < m.col; j++)
        {
            scanf("%d",&m.matrix[i][j]);
        }
  }
   return m;
}


void Multiplication(Matrix *m,Matrix *n)
{
    int i,j,k,sum=0;
    int arr[10][10];
    
    Matrix mul;
    mul.row=m->row;
    mul.col=n->col;
   
    
     mul.matrix=(int**)malloc(mul.row * sizeof(int*));
    
     for (i = 0; i < mul.row; i++)
     {
         mul.matrix[i]=(int *)malloc(mul.col * sizeof(int));
     }

    if(m->col != n->row)
    {
         printf("Matrix Multiplication is not possibale first matrix row and second matrix columns are not same.");
    }
    else
    {
         for (i = 0;i<m->row;i++)
         { 
             for (j = 0;j<m->col;j++)
             { 
                 for (k = 0;k<n->row;k++)
                 {
                        sum+=m->matrix[i][k]*n->matrix[k][j];
                            
                 }
                
                 mul.matrix[i][j]=sum;
                 printf("%d ",mul.matrix[i][j]);
                 sum=0;
                }
             printf("\n");
         }
         
         
    }
    
    
    
}


int main()
{
        int i,j;
        Matrix A,B,C;
        printf("Creating Matrix A:\n");
        A=Create();
        printf("Creating Matrix B:\n");
        B=Create();
        printf("\n\n(A*B):\n");
        Multiplication(&A,&B);
        printf("\n\n(B*A):\n");
        Multiplication(&B,&A);
      
            
        
        return 0;

}

