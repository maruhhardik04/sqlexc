/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

typedef struct{
    int matrix[10][10];
}Matrix;

int main()
{
    
    Matrix unit;
    Matrix null;
    
    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 2; j++) {
            unit.matrix[i][j]=0;
            null.matrix[i][j]=0;
            
            if(i==j)
                unit.matrix[i][j]=1;
        }
    }
    
    
    printf("Null Matrix:\n");
    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 2; j++) {
            printf("%d",null.matrix[i][j]);
        }
        printf("\n");
    }
    
    
    printf("Unit Matrix:\n");
    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 2; j++) {
            printf("%d",unit.matrix[i][j]);
        }
        printf("\n");
    }
    

    return 0;
}
