#include<stdio.h>
#include<conio.h>



int main()
{
    
    int M[10][10],v,outd,ind,i,j;
    clrscr();
    printf("Enter the number of Vertice:");
    scanf("%d",&v);


    for(i=0;i<v;i++)
        for (j=0;j<v;j++)
        {
            scanf("%d",&M[i][j]);
        }

    for (i = 0;i<v;i++)
    {
        outd=0;
        ind=0;
        for(j=0;j<v;j++)
        {
            if(M[i][j]==1)
            {
                outd++;
            }

            if(M[j][i]==1)
            {
                ind++;
            }
        }
        
        printf("Vertex %d Indegree: %d and Outdegree:%d",i+1,ind,outd);

    }
        

}