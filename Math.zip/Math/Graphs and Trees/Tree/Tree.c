#include<stdio.h>
#include<stdlib.h>
struct Node 
{
    int data;
    struct Node* left;
    struct  Node* right; 
};

struct Node* CreateNode(int data)
{
  struct Node *node;
  node=(struct Node*)malloc(sizeof(struct Node));
    

    node->data=data;
    node->left=NULL;
    node->right=NULL;

    return node;

}

void Inorder(struct Node *p)
{
    if(p == NULL) return;
    Inorder(p->left);
    printf("%d ",p->data);
    Inorder(p->right);
    
}

 void Preorder(struct Node *p)
 {
    if(p == NULL) return;
    printf("%d ",p->data);
    Preorder(p->left);
    Preorder(p->right);
}


void Postorder(struct Node *p)
 {
    if(p == NULL) return;
    Preorder(p->left);
    Preorder(p->right);
    printf("%d ",p->data);
}

int main()
{

struct Node *root;
root=CreateNode(1);

root->left=CreateNode(2);
root->right=CreateNode(3);
root->left->left=CreateNode(4);
root->left->right=CreateNode(5);
root->right->left=CreateNode(6);
 root->right->right=CreateNode(7);

printf("Pre-order:\n");
Preorder(root);

printf("\nIn-order:\n");
Inorder(root);

printf("\nPost-order:\n");
Postorder(root);

}