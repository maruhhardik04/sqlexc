CREATE TABLE Employee(
    eid int, 
    fname VARCHAR2(10), 
    lname VARCHAR2(10), 
    salary NUMBER);