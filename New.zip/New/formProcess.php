<?php
if(isset($_POST['name']))
{
    echo "<br>".$_POST['name'];
}


?>
