<?php

include 'config.php';


        $sql="SELECT * FROM institute";
        $res=$conn->query($sql);

        ?>
<table border="1">
    <?php 
        
        if($res->num_rows>0){
        while($row=$res->fetch_assoc()){
    
    ?>
    <tbody>
        <tr>
            <td><?=$row['id']?></td>
            <td><a href="?iid=<?=$row['id']?>"><?=$row['Name']?></a></td>
        </tr>    
    </tbody>
    <?php } 
        } ?>
</table>

<?php
    
    if(isset($_GET['iid']))
    {   
        $id=$_GET['iid'];
        $sql="SELECT id,Name FROM department where Isid=$id";
        $res=$conn->query($sql);
    }
?> 

<br>
<table border="1">
    <?php 
        
        if($res->num_rows>0){
        while($row=$res->fetch_assoc()){
    
    ?>
    <tbody>
        <tr>
            <td><?=$row['id']?></td>
            <td><a href="?did=<?=$row['id']?>"><?=$row['Name']?></a></td>
        </tr>    
    </tbody>
    <?php } 
        } ?>
</table>


<?php

    if( isset($_GET['did']))
    {   
        $id=$_GET['did'];
        
        $sql="SELECT `id`, `DId`, `Name` FROM `faculties` WHERE `DId`=$id";
           
        $res=$conn->query($sql);
    }
?> 

<br>
<table border="1">
    <?php 
        
        if($res->num_rows>0){
        while($row=$res->fetch_object()){
    
    ?>
    <tbody>
        <tr>
            <td><?=$row->id?></td>
            <td><?=$row->Name?></td>
        </tr>    
    </tbody>
    <?php } 
        } ?>
</table>

