<?php

setcookie("Name","Shadow",time()+86400);


if(isset($_COOKIE["Name"]))
    echo $_COOKIE["Name"];
else
    echo "Cookie is not set";