<!-- 3. Write a PHP Program to perform following operation on Array where values in 
array are entered by user
a) Print the values of array.
b) Reverse an array.
c) merge two arrays in sorted manner.
d) add values of all elements of an array -->
<?php

$a=array("fname"=>"Hardik","mname"=>"Dineshbahi","lname"=>"Maru");

$cars=array("Volvo","BMW","Toyota");


for($i=0;$i<count($cars);$i++){

    echo $cars[$i]."<br>";

}

echo "<br>Using ForEach Loop<br>";
foreach($cars as $car)
{
    echo $car."<br>";
}

echo "<br>Reverse an array<br>";
for($i=count($cars)-1;$i>=0;$i--){

    echo $cars[$i]."<br>";

}
print_r(array_reverse($cars));
echo "<br>";



echo "<br>merge two arrays in sorted manner<br>";
sort($cars);
asort($a);
print_r(array_merge($cars,$a));

echo "<br><br>add values of all elements of an array<br>";
$nums=array(1,2,3,4,5,6);
$sum=0;
for($i=0;$i<count($nums);$i++)
{
    echo $nums[$i];
    if($i!=count($nums)-1)
    {
        echo "+";
    }
    $sum+=$nums[$i];    
}
echo "=".$sum;

/*
print_r($a);
echo "<br>";


asort($a);
print_r($a);
echo "<br>";

arsort($a);
print_r($a);
echo "<br>";


ksort($a);
print_r($a);
echo "<br>";

krsort($a);
print_r($a);
echo "<br>";
*/




?>