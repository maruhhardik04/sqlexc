<?php

session_start();

date_default_timezone_set("Asia/Calcutta");

$time=date("d-M-y h:i:s A");

if(isset($_SESSION['count']))
{
    echo "<br>Welcome back";
    $_SESSION['count']+=1;

}
else
{
    echo "<br>Welcome user,you have visited this first time";
    $_SESSION['count']=1;
}

echo "<br> Total page count:".$_SESSION['count'];
if(isset($_SESSION['ltime']))
{
    echo "<br>Last Time Visited At:".$_SESSION['ltime'];
}

$_SESSION['ltime']=$time;

?>