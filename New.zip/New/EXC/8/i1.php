<?php
$val=1;

if(isset($_COOKIE['count']))
{

    setcookie("count",($_COOKIE['count']+$val),time()+3600);
    echo "<br>Welcome back";
    echo "<br> Total page count:".$_COOKIE['count'];
    echo "<br>".$_SESSION['color'];   

}
else
{
    setcookie("count",$val,time()+3600);
    echo "<br>Welcome user,you have visited this first time.<br>";
    $_COOKIE['count']=1;
?>

<body >
        <form  method="post">
        <label for="red">
            <input type="radio" name="color" value="red" checked>
            Red
        </label>
        <label for="blue">
     
            <input type="radio" name="color" value="blue">
            Blue
        </label>
        <label for="green">
   
            <input type="radio" name="color"  value="green">
            Green
        </label>
        </form>
</body>
</html>
<?php }
if(isset($_POST))
{
    $_SESSION['color']=$_POST['color'];
}

?>