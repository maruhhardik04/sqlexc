<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employess Form</title>
</head>
<style>
        
        
    </style>
<body>
    
        <H1>Employess Details</H1>
        <form action="salary.php" method="post">
            Name: <input type="text" name="name" required><br>
            Mobile Number: <input type="text" name="mnumber" minlength="10" maxlength="10"  required><br>
            Email: <input type="email" name="email" required><br>
            Salary: <input type="number" name="salary" required><br>
            <input type="submit" value="Submit">
        </form>  
        
        
</body>
</html>