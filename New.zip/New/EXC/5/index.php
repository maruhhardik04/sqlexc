<!-- 5. Write a PHP program to perform following string operations:
a) print your name.
b) print the size of a string. Pass string as an argument.
c) concat two strings.
d) convert case of string
e) find one string from another -->



<?php
$name="Hardik";

echo "Name:".$name;

echo "<br>-------------------------------------<br>";

function lengthOfString($str)
{
    echo "Size of String:".strlen($str);
}

lengthOfString("Hardik");

echo "<br>-------------------------------------<br>";


$lname=" Maru";
echo "Last Name:".$lname."<br>";

$name=$name.$lname;
echo $name;

echo "<br>-------------------------------------<br>";

echo strtoupper($name);
echo "<br>";
echo strtolower($name);

echo "<br>-------------------------------------<br>";


// if(strpos($name,$lname) !== false)
// {
//     echo "String Found!";
// }else{
//     echo "String Not Found!";
// }

echo strpos($name,$lname);


?>
