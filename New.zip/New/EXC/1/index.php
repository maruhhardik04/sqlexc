<?php 

date_default_timezone_set("Asia/Calcutta");

$time=date("H");

if($time < 12)
    echo "<h1 style='color:green'>Good Morning</h1>";
elseif($time>=12 && $time<17)
    echo "<h2 style='color:red'>Good Afternoon</h2>";
elseif($itme>=17 && $time=19)
    echo "Good Evening";
elseif($time>=19)
    echo "Good Night"; 
    

?>