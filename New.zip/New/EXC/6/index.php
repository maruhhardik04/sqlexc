<!-- 6. Write a PHP program to find out maximum and minimum number -->

<?php



function maxNumber(...$nums)
{
    $max=$nums[0];
    foreach($nums as $num)
    {
        echo " ".$num;
        if($num>=$max)
        {
            $max=$num; 
        }

    }
    echo "<br>Max:".$max;
}


function minNumber(...$nums)
{
    
    $min=$nums[0];
    foreach($nums as $num)
    {
        echo " ".$num;
        if($num<$min)
        {
            $min=$num; 
        }

    }
    echo "<br>Min:".$min;
}


maxNumber(1,2,3,9,8,7,22);
echo "<br>";
minNumber(9,8,7,6);