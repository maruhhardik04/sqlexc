<!-- 4. Write a PHP function
a) to print your name.
b) to print the size of a string. Pass string as an argument
c) to accept variable length arguments and display sum of all values and total number
 of arguments. -->

<?php

function printName($name)
{
    echo "Name:".$name;
}
printName("Hardik");

echo "<br>-------------------------------------<br>";

function lengthOfString($str)
{
    echo "Size of String:".strlen($str);
}

lengthOfString("Hardik");

echo "<br>-------------------------------------<br>";

function sumOfNumber(...$nums)
{
    $sum=0;

    foreach($nums as $num) {
        $sum+=$num;
        echo " ".$num;
    }

    echo "<br>Sum:".$sum; 
}

sumOfNumber(1,2,3,4,5);

?>


