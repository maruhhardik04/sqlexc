<?php

$fullpath = $_REQUEST['fileSRC'];


if($fullpath)
{
    $fsize=filesize($fullpath);
    $path_parts=pathinfo($fullpath);



    header("Content-type: application/octet-stream");
    header("Content-Disposition:filename=\"".$path_parts["basename"]."\"");
//    header("Content-Disposition:filename=\${$path_parts['basename']}\"); 
    if($fsize)
        header("Content-length:$fsize");
    else
        header("location:inndex1.php");    

    
    readfile($fullpath);
    exit;
}

?>