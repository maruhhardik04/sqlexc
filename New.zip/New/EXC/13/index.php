<?php require 'config.php'?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-mail registration</title>
</head>
<body>
        <form method="post">

            <label for="Name">
                <input type="text" name="fname" placeholder="First Name">
                <input type="text" name="mname" placeholder="Middle Name">
                <input type="text" name="lname" placeholder="Last Name">
            </label>
            <br/>
            <label for="Email">
                <input type="email" name="email" placeholder="Email">
            </label>
            <br/>
            <label for="Password">
                <input type="password" name="pass" placeholder="Password">
            </label>
            <br/>
            <label for="Cpassword">
                <input type="password" name="cpass" placeholder="Confirm Password">
            </label>
            <input type="submit" name="submit"  value="Register">
        </form>
</body>

</html>
<?php

    if(isset($_POST['submit']))
    {
        $fname=$_POST['fname'];
        $mname=$_POST['mname'];
        $lname=$_POST['lname'];
        $email=$_POST['email'];

        if($_POST['pass']===$_POST['cpass'])
        {
            $pass=$_POST['pass'];
            $name=$fname." ".$mname." ".$lname;
            $sql="insert into login(`username`, `Email`, `password`)values('$name','$email','$pass')";
           $res=$conn->query($sql);
            
             if($res)
             {
                echo "<script>alert('Email Registration is Completed.')</script>";
                 header("loaction:index.php");
             }
      
        }
        else
        {
            echo "<script>alert('Password and Confirm is not same')</script>";
        }
        


    }


?>