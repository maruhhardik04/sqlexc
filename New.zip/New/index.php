<!DOCTYPE html>



<!-- <script>
    
    document.addEventListener('DOMContentLoaded',function()
    {

        document.querySelector('form').onsubmit = ()=>{
                let name = document.querySelector('#name').value;
                console.log(name);
                document.querySelector('h1').innerHTML=name;
        };
    }); -->

</script>


<form> 
<input type="text" name="name" id="name">
<input type="submit">
</form> 
<h1></h1>
</html>